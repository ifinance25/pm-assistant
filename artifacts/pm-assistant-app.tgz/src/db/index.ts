import Database from "better-sqlite3";
import { mkdirSync } from "node:fs";
import { dirname, isAbsolute, join } from "node:path";
import { migrate } from "./schema.ts";
import type {
  ActionItem,
  CreateMeetingInput,
  Job,
  Meeting,
  MeetingStatus,
  Platform,
  RecordingMode,
  SearchMeetingsFilters,
  Settings,
  Summary,
  TranscriptSegment,
  WebhookDelivery,
  WebhookDeliveryStatus,
} from "../shared/types.ts";

const DEFAULT_DB_FILE = "data/app.sqlite";
export const STALE_JOB_ERROR = "задание зависло и снято с очереди";
export const JOIN_JOB_STALE_MS = 4 * 60 * 60 * 1000;
export const OTHER_JOB_STALE_MS = 30 * 60 * 1000;

function resolveDbPath(path: string): string {
  if (path === ":memory:" || isAbsolute(path)) {
    return path;
  }
  return join(process.cwd(), path);
}

function defaultDbPath(): string {
  return process.env.PM_ASSISTANT_DB_PATH ?? DEFAULT_DB_FILE;
}

function rowToMeeting(row: Record<string, unknown>): Meeting {
  return {
    id: String(row.id),
    url: String(row.url),
    platform: row.platform as Platform,
    title: row.title == null ? null : String(row.title),
    status: row.status as MeetingStatus,
    recordingMode: row.recording_mode as RecordingMode,
    startedAt: row.started_at == null ? null : String(row.started_at),
    endedAt: row.ended_at == null ? null : String(row.ended_at),
    error: row.error == null ? null : String(row.error),
    announcementStatus:
      row.announcement_status == null ? null : String(row.announcement_status),
    source: row.source as Meeting["source"],
    audioPath: row.audio_path == null ? null : String(row.audio_path),
  };
}

function parseBool(value: string): boolean {
  return value === "true" || value === "1";
}

export function createDb(path = defaultDbPath()) {
  const resolved = resolveDbPath(path);
  if (resolved !== ":memory:") {
    mkdirSync(dirname(resolved), { recursive: true });
  }
  const sqlite = new Database(resolved);
  sqlite.pragma("journal_mode = WAL");
  sqlite.pragma("foreign_keys = ON");
  migrate(sqlite);

  const selectMeetings = sqlite.prepare("SELECT * FROM meetings ORDER BY id");
  const selectMeeting = sqlite.prepare("SELECT * FROM meetings WHERE id = ?");
  const insertMeeting = sqlite.prepare(`
    INSERT INTO meetings (
      id, url, platform, title, status, recording_mode,
      started_at, ended_at, error, announcement_status, source, audio_path
    ) VALUES (
      @id, @url, @platform, @title, @status, @recording_mode,
      @started_at, @ended_at, @error, @announcement_status, @source, @audio_path
    )
  `);
  const updateStatus = sqlite.prepare(`
    UPDATE meetings SET
      status = @status,
      error = @error,
      announcement_status = @announcement_status,
      source = @source,
      audio_path = @audio_path,
      started_at = @started_at,
      ended_at = @ended_at
    WHERE id = @id
  `);
  const selectSettings = sqlite.prepare("SELECT key, value FROM settings");
  const upsertSetting = sqlite.prepare(`
    INSERT INTO settings (key, value) VALUES (@key, @value)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `);
  const insertSegment = sqlite.prepare(`
    INSERT INTO transcript_segments (
      id, meeting_id, speaker, started_at_ms, ended_at_ms, text
    ) VALUES (
      @id, @meeting_id, @speaker, @started_at_ms, @ended_at_ms, @text
    )
  `);
  const deleteSegments = sqlite.prepare(
    "DELETE FROM transcript_segments WHERE meeting_id = ?",
  );
  const selectSegments = sqlite.prepare(
    "SELECT * FROM transcript_segments WHERE meeting_id = ? ORDER BY started_at_ms",
  );
  const upsertSummary = sqlite.prepare(`
    INSERT INTO summaries (meeting_id, headline, decisions, risks, next_step)
    VALUES (@meeting_id, @headline, @decisions, @risks, @next_step)
    ON CONFLICT(meeting_id) DO UPDATE SET
      headline = excluded.headline,
      decisions = excluded.decisions,
      risks = excluded.risks,
      next_step = excluded.next_step
  `);
  const selectSummary = sqlite.prepare(
    "SELECT * FROM summaries WHERE meeting_id = ?",
  );
  const insertActionItem = sqlite.prepare(`
    INSERT INTO action_items (
      id, meeting_id, assignee, title, due_at, timecode_ms, segment_id, asana_state
    ) VALUES (
      @id, @meeting_id, @assignee, @title, @due_at, @timecode_ms, @segment_id, @asana_state
    )
  `);
  const selectActionItems = sqlite.prepare(
    "SELECT * FROM action_items WHERE meeting_id = ? ORDER BY id",
  );
  const markAsana = sqlite.prepare(
    "UPDATE action_items SET asana_state = 'queued_for_asana' WHERE id = ?",
  );
  const markAsanaSent = sqlite.prepare(
    "UPDATE action_items SET asana_state = 'sent' WHERE id = ?",
  );
  const insertJob = sqlite.prepare(`
    INSERT INTO jobs (id, meeting_id, type, status, attempts, last_error, claimed_at)
    VALUES (@id, @meeting_id, @type, @status, @attempts, @last_error, @claimed_at)
  `);
  const selectAllJobs = sqlite.prepare("SELECT * FROM jobs ORDER BY id");
  const selectNextJob = sqlite.prepare(
    "SELECT * FROM jobs WHERE status = 'pending' ORDER BY id LIMIT 1",
  );
  const selectRunningJob = sqlite.prepare(
    "SELECT id FROM jobs WHERE status = 'running' LIMIT 1",
  );
  const claimJob = sqlite.prepare(
    "UPDATE jobs SET status = 'running', attempts = attempts + 1, claimed_at = ? WHERE id = ? AND status = 'pending'",
  );
  const finishJobStmt = sqlite.prepare(
    "UPDATE jobs SET status = 'done' WHERE id = ?",
  );
  const failJobStmt = sqlite.prepare(
    "UPDATE jobs SET status = 'failed', last_error = ? WHERE id = ?",
  );
  const upsertFts = sqlite.prepare(`
    INSERT INTO meetings_fts (meeting_id, content) VALUES (?, ?)
  `);
  const deleteFts = sqlite.prepare(
    "DELETE FROM meetings_fts WHERE meeting_id = ?",
  );
  const searchFts = sqlite.prepare(`
    SELECT meeting_id FROM meetings_fts WHERE meetings_fts MATCH ? 
  `);
  const insertWebhookDelivery = sqlite.prepare(`
    INSERT INTO webhook_deliveries (
      id, meeting_id, url, status, detail, created_at
    ) VALUES (
      @id, @meeting_id, @url, @status, @detail, @created_at
    )
  `);
  const selectWebhookDeliveries = sqlite.prepare(
    "SELECT * FROM webhook_deliveries ORDER BY created_at, id",
  );

  function rebuildFts(meetingId: string): void {
    const meeting = getMeeting(meetingId);
    if (!meeting) {
      return;
    }
    const segments = listTranscript(meetingId);
    const summary = getSummary(meetingId);
    const items = listActionItems(meetingId);
    const parts = [
      meeting.title ?? "",
      meeting.url,
      ...segments.map((s) => s.text),
      summary?.headline ?? "",
      summary?.decisions ?? "",
      summary?.risks ?? "",
      summary?.nextStep ?? "",
      ...items.map((item) => item.title),
    ];
    deleteFts.run(meetingId);
    upsertFts.run(meetingId, parts.join(" "));
  }

  function listMeetings(): Meeting[] {
    return (selectMeetings.all() as Record<string, unknown>[]).map(rowToMeeting);
  }

  function getMeeting(id: string): Meeting | null {
    const row = selectMeeting.get(id) as Record<string, unknown> | undefined;
    return row ? rowToMeeting(row) : null;
  }

  function createMeeting(input: CreateMeetingInput): Meeting {
    const id = crypto.randomUUID();
    insertMeeting.run({
      id,
      url: input.url,
      platform: input.platform ?? "unknown",
      title: input.title ?? null,
      status: "queued",
      recording_mode: input.recordingMode ?? "text",
      started_at: null,
      ended_at: null,
      error: null,
      announcement_status: null,
      source: input.source ?? "stub",
      audio_path: null,
    });
    rebuildFts(id);
    const created = getMeeting(id);
    if (!created) {
      throw new Error("не удалось создать встречу");
    }
    return created;
  }

  function searchMeetings(
    query: string,
    filters: SearchMeetingsFilters = {},
  ): Meeting[] {
    const trimmed = query.trim();
    let ids: string[];
    if (!trimmed) {
      ids = listMeetings().map((m) => m.id);
    } else {
      ids = (searchFts.all(trimmed) as { meeting_id: string }[]).map(
        (row) => row.meeting_id,
      );
    }
    return ids
      .map((id) => getMeeting(id))
      .filter((m): m is Meeting => m !== null)
      .filter((m) => (filters.platform ? m.platform === filters.platform : true));
  }

  function updateMeetingStatus(
    id: string,
    status: MeetingStatus,
    extra: {
      error?: string | null;
      announcementStatus?: string | null;
      source?: Meeting["source"];
      audioPath?: string | null;
      startedAt?: string | null;
      endedAt?: string | null;
    } = {},
  ): Meeting {
    const existing = getMeeting(id);
    if (!existing) {
      throw new Error("встреча не найдена");
    }
    updateStatus.run({
      id,
      status,
      error: extra.error === undefined ? existing.error : extra.error,
      announcement_status:
        extra.announcementStatus === undefined
          ? existing.announcementStatus
          : extra.announcementStatus,
      source: extra.source === undefined ? existing.source : extra.source,
      audio_path:
        extra.audioPath === undefined ? existing.audioPath : extra.audioPath,
      started_at:
        extra.startedAt === undefined ? existing.startedAt : extra.startedAt,
      ended_at: extra.endedAt === undefined ? existing.endedAt : extra.endedAt,
    });
    const updated = getMeeting(id);
    if (!updated) {
      throw new Error("встреча не найдена");
    }
    return updated;
  }

  function listTranscript(meetingId: string): TranscriptSegment[] {
    return (selectSegments.all(meetingId) as Record<string, unknown>[]).map(
      (row) => ({
        id: String(row.id),
        meetingId: String(row.meeting_id),
        speaker: String(row.speaker),
        startedAtMs: Number(row.started_at_ms),
        endedAtMs: row.ended_at_ms == null ? null : Number(row.ended_at_ms),
        text: String(row.text),
      }),
    );
  }

  function saveTranscript(
    meetingId: string,
    segments: Omit<TranscriptSegment, "id" | "meetingId">[],
  ): TranscriptSegment[] {
    deleteSegments.run(meetingId);
    for (const segment of segments) {
      insertSegment.run({
        id: crypto.randomUUID(),
        meeting_id: meetingId,
        speaker: segment.speaker,
        started_at_ms: segment.startedAtMs,
        ended_at_ms: segment.endedAtMs,
        text: segment.text,
      });
    }
    rebuildFts(meetingId);
    return listTranscript(meetingId);
  }

  function getSummary(meetingId: string): Summary | null {
    const row = selectSummary.get(meetingId) as Record<string, unknown> | undefined;
    if (!row) {
      return null;
    }
    return {
      meetingId: String(row.meeting_id),
      headline: String(row.headline),
      decisions: String(row.decisions),
      risks: String(row.risks),
      nextStep: String(row.next_step),
    };
  }

  function saveSummary(
    meetingId: string,
    summary: Omit<Summary, "meetingId">,
  ): Summary {
    upsertSummary.run({
      meeting_id: meetingId,
      headline: summary.headline,
      decisions: summary.decisions,
      risks: summary.risks,
      next_step: summary.nextStep,
    });
    rebuildFts(meetingId);
    const saved = getSummary(meetingId);
    if (!saved) {
      throw new Error("не удалось сохранить резюме");
    }
    return saved;
  }

  function listActionItems(meetingId: string): ActionItem[] {
    return (selectActionItems.all(meetingId) as Record<string, unknown>[]).map(
      (row) => ({
        id: String(row.id),
        meetingId: String(row.meeting_id),
        assignee: row.assignee == null ? null : String(row.assignee),
        title: String(row.title),
        dueAt: row.due_at == null ? null : String(row.due_at),
        timecodeMs: row.timecode_ms == null ? null : Number(row.timecode_ms),
        segmentId: row.segment_id == null ? null : String(row.segment_id),
        asanaState: row.asana_state as ActionItem["asanaState"],
      }),
    );
  }

  function saveActionItems(
    meetingId: string,
    items: Omit<ActionItem, "id" | "meetingId" | "asanaState">[],
  ): ActionItem[] {
    for (const item of items) {
      insertActionItem.run({
        id: crypto.randomUUID(),
        meeting_id: meetingId,
        assignee: item.assignee,
        title: item.title,
        due_at: item.dueAt,
        timecode_ms: item.timecodeMs,
        segment_id: item.segmentId,
        asana_state: "none",
      });
    }
    rebuildFts(meetingId);
    return listActionItems(meetingId);
  }

  function markActionItemsQueuedForAsana(ids: string[]): void {
    const tx = sqlite.transaction((itemIds: string[]) => {
      for (const id of itemIds) {
        markAsana.run(id);
      }
    });
    tx(ids);
  }

  function markActionItemsSentToAsana(ids: string[]): void {
    const tx = sqlite.transaction((itemIds: string[]) => {
      for (const id of itemIds) {
        markAsanaSent.run(id);
      }
    });
    tx(ids);
  }

  function getSettings(): Settings {
    const rows = selectSettings.all() as { key: string; value: string }[];
    const map = new Map(rows.map((row) => [row.key, row.value]));
    return {
      recordingModeDefault: (map.get("recordingModeDefault") ??
        "text") as RecordingMode,
      asanaProjectLabel: map.get("asanaProjectLabel") ?? "",
      asanaAutoSend: parseBool(map.get("asanaAutoSend") ?? "false"),
      webhookUrl: map.get("webhookUrl") ?? "",
      workerHeartbeatAt: map.get("workerHeartbeatAt") ?? null,
    };
  }

  function putSettings(patch: Partial<Settings>): Settings {
    if (patch.recordingModeDefault !== undefined) {
      upsertSetting.run({
        key: "recordingModeDefault",
        value: patch.recordingModeDefault,
      });
    }
    if (patch.asanaProjectLabel !== undefined) {
      upsertSetting.run({
        key: "asanaProjectLabel",
        value: patch.asanaProjectLabel,
      });
    }
    if (patch.asanaAutoSend !== undefined) {
      upsertSetting.run({
        key: "asanaAutoSend",
        value: patch.asanaAutoSend ? "true" : "false",
      });
    }
    if (patch.webhookUrl !== undefined) {
      upsertSetting.run({
        key: "webhookUrl",
        value: patch.webhookUrl,
      });
    }
    if (patch.workerHeartbeatAt !== undefined) {
      upsertSetting.run({
        key: "workerHeartbeatAt",
        value: patch.workerHeartbeatAt ?? "",
      });
    }
    return getSettings();
  }

  function recordWebhookDelivery(input: {
    meetingId: string;
    url: string;
    status: WebhookDeliveryStatus;
    detail: string;
  }): WebhookDelivery {
    const id = crypto.randomUUID();
    const createdAt = new Date().toISOString();
    insertWebhookDelivery.run({
      id,
      meeting_id: input.meetingId,
      url: input.url,
      status: input.status,
      detail: input.detail,
      created_at: createdAt,
    });
    return {
      id,
      meetingId: input.meetingId,
      url: input.url,
      status: input.status,
      detail: input.detail,
      createdAt,
    };
  }

  function listWebhookDeliveries(): WebhookDelivery[] {
    return (selectWebhookDeliveries.all() as Record<string, unknown>[]).map(
      (row) => ({
        id: String(row.id),
        meetingId: String(row.meeting_id),
        url: String(row.url),
        status: row.status as WebhookDeliveryStatus,
        detail: String(row.detail),
        createdAt: String(row.created_at),
      }),
    );
  }

  function rowToJob(row: Record<string, unknown>): Job {
    return {
      id: String(row.id),
      meetingId: String(row.meeting_id),
      type: String(row.type),
      status: String(row.status),
      attempts: Number(row.attempts),
      lastError: row.last_error == null ? null : String(row.last_error),
      claimedAt: row.claimed_at == null ? null : String(row.claimed_at),
    };
  }

  function listJobs(): Job[] {
    return (selectAllJobs.all() as Record<string, unknown>[]).map(rowToJob);
  }

  function enqueueJob(input: { meetingId: string; type: string }): Job {
    const id = crypto.randomUUID();
    insertJob.run({
      id,
      meeting_id: input.meetingId,
      type: input.type,
      status: "pending",
      attempts: 0,
      last_error: null,
      claimed_at: null,
    });
    return {
      id,
      meetingId: input.meetingId,
      type: input.type,
      status: "pending",
      attempts: 0,
      lastError: null,
      claimedAt: null,
    };
  }

  function failStaleRunningJobs(maxAgeMs?: number): Job[] {
    const now = Date.now();
    const failed: Job[] = [];
    for (const job of listJobs()) {
      if (job.status !== "running") {
        continue;
      }
      const claimedMs = job.claimedAt ? Date.parse(job.claimedAt) : Number.NaN;
      const ageMs = Number.isFinite(claimedMs)
        ? now - claimedMs
        : Number.POSITIVE_INFINITY;
      const limit =
        maxAgeMs ??
        (job.type === "join" ? JOIN_JOB_STALE_MS : OTHER_JOB_STALE_MS);
      if (ageMs < limit) {
        continue;
      }
      failJob(job.id, STALE_JOB_ERROR);
      failed.push({
        ...job,
        status: "failed",
        lastError: STALE_JOB_ERROR,
      });
    }
    return failed;
  }

  function failAllRunningJobs(lastError: string): Job[] {
    const failed: Job[] = [];
    for (const job of listJobs()) {
      if (job.status !== "running") {
        continue;
      }
      failJob(job.id, lastError);
      failed.push({ ...job, status: "failed", lastError });
    }
    return failed;
  }

  function claimNextJob(): Job | null {
    failStaleRunningJobs();
    const running = selectRunningJob.get() as Record<string, unknown> | undefined;
    if (running) {
      return null;
    }
    const row = selectNextJob.get() as Record<string, unknown> | undefined;
    if (!row) {
      return null;
    }
    const claimedAt = new Date().toISOString();
    const result = claimJob.run(claimedAt, String(row.id));
    if (result.changes === 0) {
      return null;
    }
    return {
      ...rowToJob(row),
      status: "running",
      attempts: Number(row.attempts) + 1,
      claimedAt,
    };
  }

  function finishJob(id: string): void {
    finishJobStmt.run(id);
  }

  function failJob(id: string, lastError: string): void {
    failJobStmt.run(lastError.slice(0, 2000), id);
  }

  return {
    createMeeting,
    listMeetings,
    getMeeting,
    searchMeetings,
    updateMeetingStatus,
    saveTranscript,
    listTranscript,
    saveSummary,
    getSummary,
    saveActionItems,
    listActionItems,
    markActionItemsQueuedForAsana,
    markActionItemsSentToAsana,
    getSettings,
    putSettings,
    recordWebhookDelivery,
    listWebhookDeliveries,
    enqueueJob,
    claimNextJob,
    listJobs,
    finishJob,
    failJob,
    failStaleRunningJobs,
    failAllRunningJobs,
    close() {
      sqlite.close();
    },
  };
}

export type Db = ReturnType<typeof createDb>;

let singleton: Db | undefined;

export function getDb(): Db {
  if (!singleton) {
    singleton = createDb();
  }
  return singleton;
}

export function setDb(db: Db): void {
  singleton = db;
}
