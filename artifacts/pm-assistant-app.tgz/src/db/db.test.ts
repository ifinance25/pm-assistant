import { afterEach, describe, expect, it } from "vitest";
import { createDb } from "./index.ts";

describe("db", () => {
  let db: ReturnType<typeof createDb>;

  afterEach(() => {
    db?.close();
  });

  it("создаёт базу с пустым списком встреч", () => {
    db = createDb(":memory:");
    expect(db.listMeetings()).toEqual([]);
  });

  it("пишет и читает настройки", () => {
    db = createDb(":memory:");
    db.putSettings({ recordingModeDefault: "full" });
    expect(db.getSettings().recordingModeDefault).toBe("full");
  });

  it("создаёт строку встречи", () => {
    db = createDb(":memory:");
    const meeting = db.createMeeting({ url: "https://zoom.us/j/123" });
    expect(meeting.url).toBe("https://zoom.us/j/123");
    expect(meeting.status).toBe("queued");
    expect(db.getMeeting(meeting.id)?.id).toBe(meeting.id);
    expect(db.listMeetings()).toHaveLength(1);
  });

  it("не берёт следующее задание, пока running жив, и снимает stale running", () => {
    db = createDb(":memory:");
    const first = db.createMeeting({ url: "https://zoom.us/j/1" });
    const second = db.createMeeting({ url: "https://zoom.us/j/2" });
    db.enqueueJob({ meetingId: first.id, type: "join" });
    db.enqueueJob({ meetingId: second.id, type: "join" });
    const claimed = db.claimNextJob();
    expect(claimed?.status).toBe("running");
    expect(db.claimNextJob()).toBeNull();
    const stale = db.failStaleRunningJobs(0);
    expect(stale).toHaveLength(1);
    const next = db.claimNextJob();
    expect(next).toBeTruthy();
    expect(next?.id).not.toBe(claimed?.id);
    expect(next?.meetingId).not.toBe(claimed?.meetingId);
  });
});
