import type Database from "better-sqlite3";

export function migrate(sqlite: Database.Database): void {
  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS meetings (
      id TEXT PRIMARY KEY,
      url TEXT NOT NULL,
      platform TEXT NOT NULL,
      title TEXT,
      status TEXT NOT NULL,
      recording_mode TEXT NOT NULL,
      started_at TEXT,
      ended_at TEXT,
      error TEXT,
      announcement_status TEXT,
      source TEXT NOT NULL,
      audio_path TEXT
    );

    CREATE TABLE IF NOT EXISTS transcript_segments (
      id TEXT PRIMARY KEY,
      meeting_id TEXT NOT NULL REFERENCES meetings(id),
      speaker TEXT NOT NULL,
      started_at_ms INTEGER NOT NULL,
      ended_at_ms INTEGER,
      text TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS summaries (
      meeting_id TEXT PRIMARY KEY REFERENCES meetings(id),
      headline TEXT NOT NULL,
      decisions TEXT NOT NULL,
      risks TEXT NOT NULL,
      next_step TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS action_items (
      id TEXT PRIMARY KEY,
      meeting_id TEXT NOT NULL REFERENCES meetings(id),
      assignee TEXT,
      title TEXT NOT NULL,
      due_at TEXT,
      timecode_ms INTEGER,
      segment_id TEXT,
      asana_state TEXT NOT NULL DEFAULT 'none'
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS jobs (
      id TEXT PRIMARY KEY,
      meeting_id TEXT NOT NULL REFERENCES meetings(id),
      type TEXT NOT NULL,
      status TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      last_error TEXT,
      claimed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS webhook_deliveries (
      id TEXT PRIMARY KEY,
      meeting_id TEXT NOT NULL REFERENCES meetings(id),
      url TEXT NOT NULL,
      status TEXT NOT NULL,
      detail TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE VIRTUAL TABLE IF NOT EXISTS meetings_fts USING fts5(
      meeting_id UNINDEXED,
      content,
      tokenize = 'unicode61'
    );
  `);

  const insertDefault = sqlite.prepare(
    "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
  );
  insertDefault.run("recordingModeDefault", "text");
  insertDefault.run("asanaProjectLabel", "");
  insertDefault.run("asanaAutoSend", "false");
  insertDefault.run("webhookUrl", "");

  const jobCols = sqlite.pragma("table_info(jobs)") as { name: string }[];
  if (!jobCols.some((col) => col.name === "claimed_at")) {
    sqlite.exec("ALTER TABLE jobs ADD COLUMN claimed_at TEXT");
  }
}
