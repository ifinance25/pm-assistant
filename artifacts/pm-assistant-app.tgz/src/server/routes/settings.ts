import { Hono } from "hono";
import { getDb } from "../../db/index.ts";
import type { Settings } from "../../shared/types.ts";

export const settingsRouter = new Hono();

settingsRouter.get("/settings", (c) => {
  return c.json(getDb().getSettings());
});

settingsRouter.put("/settings", async (c) => {
  const patch = (await c.req.json()) as Partial<Settings>;
  return c.json(getDb().putSettings(patch));
});
