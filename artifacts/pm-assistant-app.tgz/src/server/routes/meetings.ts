import { existsSync, statSync } from "node:fs";
import { Hono } from "hono";
import { detectPlatform } from "../../adapters/platform/index.ts";
import { getDb } from "../../db/index.ts";
import type { Meeting, MeetingStatus } from "../../shared/types.ts";

const IN_PROGRESS: MeetingStatus[] = ["queued", "joining", "recording"];

export const meetingsRouter = new Hono();

export { detectPlatform };

function storageStats(meetings: Meeting[]) {
  let usedBytes = 0;
  for (const meeting of meetings) {
    if (meeting.audioPath && existsSync(meeting.audioPath)) {
      usedBytes += statSync(meeting.audioPath).size;
    }
  }
  return { meetingCount: meetings.length, usedBytes };
}

meetingsRouter.get("/", (c) => {
  const meetings = getDb().listMeetings();
  return c.json({
    meetings,
    storage: storageStats(meetings),
  });
});

meetingsRouter.post("/", async (c) => {
  let body: { url?: unknown };
  try {
    body = (await c.req.json()) as { url?: unknown };
  } catch {
    return c.json({ error: "Вставьте ссылку на встречу" }, 400);
  }
  const url = typeof body.url === "string" ? body.url.trim() : "";
  if (!url) {
    return c.json({ error: "Вставьте ссылку на встречу" }, 400);
  }
  const platform = detectPlatform(url);
  if (!platform) {
    return c.json(
      { error: "Ссылка не похожа на Zoom, Google Meet или Телемост" },
      400,
    );
  }
  const db = getDb();
  const existing = db.listMeetings().find(
    (meeting) => meeting.url === url && IN_PROGRESS.includes(meeting.status),
  );
  if (existing) {
    return c.json({ meeting: existing, alreadyRunning: true }, 200);
  }
  const settings = db.getSettings();
  const meeting = db.createMeeting({
    url,
    platform,
    recordingMode: settings.recordingModeDefault,
    source: "stub",
  });
  db.enqueueJob({ meetingId: meeting.id, type: "join" });
  return c.json({ meeting, alreadyRunning: false }, 201);
});
