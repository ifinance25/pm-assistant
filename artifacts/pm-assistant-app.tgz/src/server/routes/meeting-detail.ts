import { Hono } from "hono";
import { dispatchActionItems } from "../../adapters/asana/index.ts";
import { getDb } from "../../db/index.ts";
import { realtimeCaption, type MeetingDetail } from "../../shared/types.ts";

export const meetingDetailRouter = new Hono();

meetingDetailRouter.get("/:id", (c) => {
  const db = getDb();
  const id = c.req.param("id");
  const meeting = db.getMeeting(id);
  if (!meeting) {
    return c.json({ error: "встреча не найдена" }, 404);
  }
  const body: MeetingDetail = {
    meeting,
    transcript: db.listTranscript(id),
    summary: db.getSummary(id),
    actionItems: db.listActionItems(id),
    realtime: {
      mode: meeting.source,
      caption: realtimeCaption(meeting.source),
    },
  };
  return c.json(body);
});

meetingDetailRouter.post("/:id/retry", (c) => {
  const db = getDb();
  const id = c.req.param("id");
  const meeting = db.getMeeting(id);
  if (!meeting) {
    return c.json({ error: "встреча не найдена" }, 404);
  }
  if (meeting.status !== "error") {
    return c.json({ error: "повторить можно после ошибки" }, 409);
  }
  if (meeting.audioPath) {
    for (const job of db.listJobs()) {
      if (
        job.meetingId === id &&
        job.type === "join" &&
        (job.status === "pending" || job.status === "running")
      ) {
        db.failJob(job.id, "есть файл звука: повторный вход не нужен");
      }
    }
    const job = db.enqueueJob({ meetingId: id, type: "transcribe" });
    return c.json({ meeting, job }, 202);
  }
  const updated = db.updateMeetingStatus(id, "queued", { error: null });
  db.enqueueJob({ meetingId: id, type: "join" });
  return c.json({ meeting: updated });
});

meetingDetailRouter.post("/:id/transcribe", (c) => {
  const db = getDb();
  const id = c.req.param("id");
  const meeting = db.getMeeting(id);
  if (!meeting) {
    return c.json({ error: "встреча не найдена" }, 404);
  }
  if (!meeting.audioPath) {
    return c.json({ error: "нет файла звука" }, 409);
  }
  const allowed = new Set([
    "ready",
    "error",
    "recording",
    "joining",
    "queued",
    "summarizing",
    "transcribing",
  ]);
  if (!allowed.has(meeting.status)) {
    return c.json(
      { error: `расшифровку нельзя запустить из статуса ${meeting.status}` },
      409,
    );
  }
  for (const job of db.listJobs()) {
    if (
      job.meetingId === id &&
      job.type === "join" &&
      (job.status === "pending" || job.status === "running")
    ) {
      db.failJob(job.id, "есть файл звука: повторный вход не нужен");
    }
  }
  const job = db.enqueueJob({ meetingId: id, type: "transcribe" });
  return c.json({ meeting, job }, 202);
});

meetingDetailRouter.post("/:id/asana-queue", async (c) => {
  const db = getDb();
  const id = c.req.param("id");
  const meeting = db.getMeeting(id);
  if (!meeting) {
    return c.json({ error: "встреча не найдена" }, 404);
  }

  let ids: string[] | undefined;
  const contentType = c.req.header("content-type") ?? "";
  if (contentType.includes("application/json")) {
    const body = (await c.req.json()) as { ids?: string[] };
    if (Array.isArray(body.ids)) {
      ids = body.ids;
    }
  }

  const items = db.listActionItems(id);
  const toQueue = ids
    ? items.filter((item) => ids.includes(item.id))
    : items.filter((item) => item.asanaState === "none");
  const asana = await dispatchActionItems(db, toQueue);

  return c.json({ actionItems: db.listActionItems(id), asana });
});
