import { Hono } from "hono";
import { restartBot } from "../bot-restart.ts";

export const botRouter = new Hono();

botRouter.post("/bot/restart", async (c) => {
  try {
    return c.json(await restartBot());
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return c.json({ error: `Не удалось перезапустить бота: ${message}` }, 500);
  }
});
