import { afterEach, describe, expect, it } from "vitest";
import { createDb, setDb } from "../db/index.ts";
import { app } from "./app.ts";

describe("GET/PUT /api/settings", () => {
  let db: ReturnType<typeof createDb>;

  afterEach(() => {
    db?.close();
  });

  it("читает настройки из базы и сохраняет правку", async () => {
    db = createDb(":memory:");
    setDb(db);
    const initial = await app.request("/api/settings");
    expect(initial.status).toBe(200);
    expect(await initial.json()).toMatchObject({
      recordingModeDefault: "text",
      asanaAutoSend: false,
    });

    const updated = await app.request("/api/settings", {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ recordingModeDefault: "full" }),
    });
    expect(updated.status).toBe(200);
    expect(await updated.json()).toMatchObject({
      recordingModeDefault: "full",
    });
    expect(db.getSettings().recordingModeDefault).toBe("full");
  });
});
