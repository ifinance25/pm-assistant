import { afterEach, describe, expect, it } from "vitest";
import { createDb, setDb } from "../db/index.ts";
import { app } from "./app.ts";

describe("GET/POST /api/meetings", () => {
  let db: ReturnType<typeof createDb>;

  afterEach(() => {
    db?.close();
  });

  it("возвращает пустой список встреч", async () => {
    db = createDb(":memory:");
    setDb(db);
    const res = await app.request("/api/meetings");
    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({
      meetings: [],
      storage: { meetingCount: 0, usedBytes: 0 },
    });
  });

  it("создаёт встречу queued по ссылке Zoom", async () => {
    db = createDb(":memory:");
    setDb(db);
    const url = "https://zoom.us/j/123456789";
    const res = await app.request("/api/meetings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ url }),
    });
    expect(res.status).toBe(201);
    const body = await res.json();
    expect(body.alreadyRunning).toBe(false);
    expect(body.meeting).toMatchObject({
      url,
      platform: "zoom",
      status: "queued",
      source: "stub",
    });
    expect(body.meeting.id).toEqual(expect.any(String));
    expect(db.listMeetings()).toHaveLength(1);
    expect(db.listMeetings()[0].id).toBe(body.meeting.id);
  });

  it("создаёт встречу queued по ссылке Google Meet", async () => {
    db = createDb(":memory:");
    setDb(db);
    const url = "https://meet.google.com/abc-defg-hij";
    const res = await app.request("/api/meetings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ url }),
    });
    expect(res.status).toBe(201);
    const body = await res.json();
    expect(body.meeting).toMatchObject({
      url,
      platform: "meet",
      status: "queued",
      source: "stub",
    });
  });

  it("создаёт встречу queued по ссылке Телемоста", async () => {
    db = createDb(":memory:");
    setDb(db);
    const url = "https://telemost.yandex.ru/j/12345678901234";
    const res = await app.request("/api/meetings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ url }),
    });
    expect(res.status).toBe(201);
    const body = await res.json();
    expect(body.meeting).toMatchObject({
      url,
      platform: "telemost",
      status: "queued",
      source: "stub",
    });
  });

  it("отклоняет пустую ссылку русской ошибкой", async () => {
    db = createDb(":memory:");
    setDb(db);
    const res = await app.request("/api/meetings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ url: "   " }),
    });
    expect(res.status).toBe(400);
    expect(await res.json()).toEqual({ error: "Вставьте ссылку на встречу" });
    expect(db.listMeetings()).toEqual([]);
  });

  it("отклоняет чужую ссылку русской ошибкой", async () => {
    db = createDb(":memory:");
    setDb(db);
    const res = await app.request("/api/meetings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ url: "https://example.com/meeting" }),
    });
    expect(res.status).toBe(400);
    expect(await res.json()).toEqual({
      error: "Ссылка не похожа на Zoom, Google Meet или Телемост",
    });
    expect(db.listMeetings()).toEqual([]);
  });

  it("не создаёт дубль встречи в статусе queued", async () => {
    db = createDb(":memory:");
    setDb(db);
    const url = "https://zoom.us/j/555111222";
    const first = await app.request("/api/meetings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ url }),
    });
    const firstBody = await first.json();
    const second = await app.request("/api/meetings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ url }),
    });
    expect(second.status).toBe(200);
    const secondBody = await second.json();
    expect(secondBody.alreadyRunning).toBe(true);
    expect(secondBody.meeting.id).toBe(firstBody.meeting.id);
    expect(db.listMeetings()).toHaveLength(1);
  });

  it("не создаёт дубль встречи в статусе joining или recording", async () => {
    db = createDb(":memory:");
    setDb(db);
    const url = "https://meet.google.com/aaa-bbbb-ccc";
    const created = await app.request("/api/meetings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ url }),
    });
    const meeting = (await created.json()).meeting;
    db.updateMeetingStatus(meeting.id, "joining");
    const again = await app.request("/api/meetings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ url }),
    });
    expect(again.status).toBe(200);
    expect((await again.json()).meeting.id).toBe(meeting.id);
    expect(db.listMeetings()).toHaveLength(1);

    db.updateMeetingStatus(meeting.id, "recording");
    const third = await app.request("/api/meetings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ url }),
    });
    expect(third.status).toBe(200);
    expect(db.listMeetings()).toHaveLength(1);
  });
});
