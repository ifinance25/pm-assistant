import { afterEach, describe, expect, it } from "vitest";
import { createDb, setDb } from "../db/index.ts";
import { app } from "./app.ts";
import { resetBotRestartDeps, setBotRestartDeps } from "./bot-restart.ts";

describe("POST /api/bot/restart", () => {
  let db: ReturnType<typeof createDb>;

  afterEach(() => {
    resetBotRestartDeps();
    db?.close();
  });

  it("снимает queued встречу и running job, повтор той же ссылки даёт 201", async () => {
    db = createDb(":memory:");
    setDb(db);
    setBotRestartDeps({
      runCommand: async () => ({ ok: true, stdout: "", stderr: "" }),
      whichDocker: () => "/usr/bin/docker",
      existsSync: () => false,
    });

    const url = "https://zoom.us/j/555111222";
    const created = await app.request("/api/meetings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ url }),
    });
    expect(created.status).toBe(201);
    const running = db.claimNextJob();
    expect(running?.status).toBe("running");

    const restart = await app.request("/api/bot/restart", { method: "POST" });
    expect(restart.status).toBe(200);
    const body = await restart.json();
    expect(body.ok).toBe(true);
    expect(body.meetingsCleared).toBe(1);
    expect(body.jobsFailed).toBe(1);
    expect(body.workerRestarted).toBe(false);
    expect(body.workerRestartMethod).toBe("skipped");
    expect(db.listMeetings()[0]?.status).toBe("error");
    expect(db.listJobs()[0]?.status).toBe("failed");

    const again = await app.request("/api/meetings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ url }),
    });
    expect(again.status).toBe(201);
    const againBody = await again.json();
    expect(againBody.alreadyRunning).toBe(false);
    expect(againBody.meeting.status).toBe("queued");
    expect(db.listMeetings()).toHaveLength(2);
  });
});
