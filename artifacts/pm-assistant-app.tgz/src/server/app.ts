import { Hono } from "hono";
import { botRouter } from "./routes/bot.ts";
import { healthRouter } from "./routes/health.ts";
import { meetingDetailRouter } from "./routes/meeting-detail.ts";
import { meetingsRouter } from "./routes/meetings.ts";
import { publicApiRouter } from "./routes/public-api.ts";
import { searchRouter } from "./routes/search.ts";
import { settingsRouter } from "./routes/settings.ts";

export const app = new Hono();

app.route("/api", healthRouter);
app.route("/api", settingsRouter);
app.route("/api", botRouter);
app.route("/api/meetings", meetingsRouter);
app.route("/api/meetings", meetingDetailRouter);
app.route("/api/search", searchRouter);
app.route("/api/public", publicApiRouter);
