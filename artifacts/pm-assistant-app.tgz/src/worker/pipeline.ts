import {
  announceRecording,
  STUB_ANNOUNCEMENT_STATUS,
} from "../adapters/announce/index.ts";
import { maybeAutoSendAsana } from "../adapters/asana/index.ts";
import { deliverReadyWebhook } from "../adapters/webhook/index.ts";
import {
  createLlmAdapter,
  type LlmAdapter,
} from "../adapters/llm/index.ts";
import { isLlmRateLimitError } from "../adapters/llm/live.ts";
import {
  liveAudioPendingSummary,
  summaryFromTranscriptOnly,
} from "../adapters/llm/pending.ts";
import {
  createJoinAdapter,
  type JoinAdapter,
  type JoinHooks,
  type JoinResult,
} from "../adapters/platform/index.ts";
import {
  createSttAdapter,
  detectSttEngine,
  type SttEngine,
  type Transcript,
} from "../adapters/stt/index.ts";
import {
  isLivePendingTranscript,
  liveAudioPendingTranscript,
} from "../adapters/stt/pending.ts";
import type { Db } from "../db/index.ts";
import type { Job, Meeting, MeetingStatus } from "../shared/types.ts";
import { meetingHasAudio, recoverStuckMeetings } from "./recover.ts";
import { assertStatusTransition } from "./status.ts";

export type ProcessJobDeps = {
  join?: JoinAdapter["join"];
  detectSttEngine?: () => SttEngine | null;
  resolveLlmKey?: () => string;
  transcribe?: (
    audioPath: string,
    detect: () => SttEngine | null,
  ) => Promise<Transcript>;
};

function setStatus(
  db: Db,
  meeting: Meeting,
  status: MeetingStatus,
  extra: Parameters<Db["updateMeetingStatus"]>[2] = {},
): Meeting {
  assertStatusTransition(meeting.status, status);
  return db.updateMeetingStatus(meeting.id, status, extra);
}

async function transcribeLive(
  join: JoinResult,
  detect: () => SttEngine | null,
): Promise<Transcript> {
  const engine = detect();
  if (!join.audioPath || !engine) {
    return liveAudioPendingTranscript(join.audioPath);
  }
  return createSttAdapter({ detectEngine: () => engine }).transcribe(
    join.audioPath,
    { languageHint: "ru" },
  );
}

async function summarizeLive(
  transcript: Transcript,
  audioPath: string | null,
  resolveKey?: () => string,
): Promise<ReturnType<LlmAdapter["summarize"]>> {
  if (isLivePendingTranscript(transcript)) {
    return liveAudioPendingSummary(audioPath);
  }
  const llm =
    resolveKey !== undefined
      ? createLlmAdapter({ apiKey: resolveKey() })
      : createLlmAdapter();
  if (llm.mode === "live") {
    return llm.summarize(transcript);
  }
  return summaryFromTranscriptOnly(transcript);
}

async function summarizeOrFallback(
  transcript: Transcript,
  audioPath: string | null,
  resolveKey?: () => string,
): Promise<ReturnType<LlmAdapter["summarize"]>> {
  try {
    return await summarizeLive(transcript, audioPath, resolveKey);
  } catch (err) {
    if (isLivePendingTranscript(transcript)) {
      throw err;
    }
    const message = err instanceof Error ? err.message : String(err);
    const reason = isLlmRateLimitError(err) ? "rate-limit" : "failed";
    console.error(`llm: ${message}, сохраняю резюме из текста`);
    return summaryFromTranscriptOnly(transcript, { reason });
  }
}

function moveToTranscribing(db: Db, meeting: Meeting): Meeting {
  if (meeting.status === "transcribing") {
    return db.updateMeetingStatus(meeting.id, meeting.status, { error: null });
  }
  if (
    meeting.status === "ready" ||
    meeting.status === "error" ||
    meeting.status === "queued" ||
    meeting.status === "joining" ||
    meeting.status === "recording" ||
    meeting.status === "summarizing"
  ) {
    return setStatus(db, meeting, "transcribing", { error: null });
  }
  throw new Error(
    `расшифровку нельзя запустить из статуса ${meeting.status}`,
  );
}

async function processTranscribeJob(
  db: Db,
  job: Job,
  meeting: Meeting,
  deps: ProcessJobDeps,
): Promise<void> {
  const audioPath = meeting.audioPath;
  if (!audioPath) {
    throw new Error("нет файла звука для расшифровки");
  }
  const detect = deps.detectSttEngine ?? detectSttEngine;
  const engine = detect();
  if (!engine && !deps.transcribe) {
    throw new Error(
      "нет whisper: задайте WHISPER_BIN=/usr/local/bin/whisper и WHISPER_MODEL",
    );
  }
  let current = moveToTranscribing(db, meeting);
  const transcript = deps.transcribe
    ? await deps.transcribe(audioPath, detect)
    : await createSttAdapter({
        detectEngine: () => engine,
      }).transcribe(audioPath, { languageHint: "ru" });
  if (isLivePendingTranscript(transcript)) {
    throw new Error("whisper не вернул текст сегментов");
  }
  db.saveTranscript(current.id, transcript.segments);
  current = setStatus(db, current, "summarizing");
  const summarized = await summarizeOrFallback(
    transcript,
    audioPath,
    deps.resolveLlmKey,
  );
  db.saveSummary(current.id, summarized.summary);
  db.saveActionItems(
    current.id,
    summarized.actionItems.map((item) => ({
      assignee: item.assignee,
      title: item.title,
      dueAt: item.dueAt,
      timecodeMs: item.timecodeMs,
      segmentId: null,
    })),
  );
  setStatus(db, current, "ready", {
    endedAt: new Date().toISOString(),
  });
  db.finishJob(job.id);
}

export async function processJob(
  db: Db,
  job: Job,
  deps: ProcessJobDeps = {},
): Promise<void> {
  const meeting = db.getMeeting(job.meetingId);
  if (!meeting) {
    throw new Error("встреча не найдена");
  }
  if (job.type === "transcribe" || meetingHasAudio(meeting)) {
    try {
      await processTranscribeJob(db, job, meeting, deps);
    } catch (err) {
      const latest = db.getMeeting(job.meetingId);
      const message = err instanceof Error ? err.message : String(err);
      db.failJob(job.id, message);
      if (latest && latest.status !== "error") {
        try {
          assertStatusTransition(latest.status, "error");
          db.updateMeetingStatus(job.meetingId, "error", { error: message });
        } catch {
          db.updateMeetingStatus(job.meetingId, "error", { error: message });
        }
      }
      throw err;
    }
    return;
  }
  try {
    let current = setStatus(db, meeting, "joining", {
      startedAt: new Date().toISOString(),
      error: null,
    });
    const joinFn =
      deps.join ??
      ((item: Meeting, hooks?: JoinHooks) =>
        createJoinAdapter().join(item, hooks));
    const join = await joinFn(current, {
      onJoined: async ({ mode }) => {
        const latest = db.getMeeting(current.id) ?? current;
        if (latest.status !== "joining") {
          return;
        }
        announceRecording({
          meeting: latest,
          join: { mode, audioPath: null },
        });
        const withMeta = db.updateMeetingStatus(latest.id, latest.status, {
          announcementStatus:
            mode === "stub" ? STUB_ANNOUNCEMENT_STATUS : "объявление отправлено",
          source: mode,
        });
        current = setStatus(db, withMeta, "recording");
      },
    });
    current = db.getMeeting(current.id) ?? current;
    if (current.status === "joining") {
      announceRecording({ meeting: current, join });
      current = db.updateMeetingStatus(current.id, current.status, {
        announcementStatus:
          join.mode === "stub" ? STUB_ANNOUNCEMENT_STATUS : "объявление отправлено",
        source: join.mode,
        audioPath: join.audioPath,
      });
      current = setStatus(db, current, "recording");
    } else {
      current = db.updateMeetingStatus(current.id, current.status, {
        source: join.mode,
        audioPath: join.audioPath,
      });
    }
    let transcript: Transcript;
    if (deps.transcribe && join.audioPath) {
      transcript = await deps.transcribe(
        join.audioPath,
        deps.detectSttEngine ?? detectSttEngine,
      );
    } else if (join.mode === "stub") {
      transcript = await createSttAdapter({
        detectEngine: () => null,
      }).transcribe(join.audioPath ?? "", { languageHint: "ru" });
    } else {
      transcript = await transcribeLive(
        join,
        deps.detectSttEngine ?? detectSttEngine,
      );
    }
    db.saveTranscript(current.id, transcript.segments);
    current = setStatus(db, current, "transcribing");
    current = setStatus(db, current, "summarizing");
    const summarized =
      join.mode === "stub"
        ? await createLlmAdapter({ apiKey: "" }).summarize(transcript)
        : await summarizeOrFallback(
            transcript,
            join.audioPath,
            deps.resolveLlmKey,
          );
    db.saveSummary(current.id, summarized.summary);
    db.saveActionItems(
      current.id,
      summarized.actionItems.map((item) => ({
        assignee: item.assignee,
        title: item.title,
        dueAt: item.dueAt,
        timecodeMs: item.timecodeMs,
        segmentId: null,
      })),
    );
    const ready = setStatus(db, current, "ready", {
      endedAt: new Date().toISOString(),
    });
    await deliverReadyWebhook(db, ready);
    await maybeAutoSendAsana(db, current.id);
    db.finishJob(job.id);
  } catch (err) {
    const latest = db.getMeeting(job.meetingId);
    const message = err instanceof Error ? err.message : String(err);
    db.failJob(job.id, message);
    if (latest && latest.status !== "error") {
      try {
        assertStatusTransition(latest.status, "error");
        db.updateMeetingStatus(job.meetingId, "error", { error: message });
      } catch {
        if (latest.status !== "ready") {
          db.updateMeetingStatus(job.meetingId, "error", { error: message });
        }
      }
    }
    throw err;
  }
}

export async function runOnce(
  db: Db,
  deps: ProcessJobDeps = {},
): Promise<boolean> {
  recoverStuckMeetings(db);
  const job = db.claimNextJob();
  if (!job) {
    return false;
  }
  await processJob(db, job, deps);
  return true;
}
