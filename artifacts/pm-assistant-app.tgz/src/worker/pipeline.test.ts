import { afterEach, describe, expect, it } from "vitest";
import { createDb } from "../db/index.ts";
import { LIVE_AUDIO_PENDING_TEXT } from "../adapters/stt/pending.ts";
import { runOnce } from "./pipeline.ts";

describe("воркер конвейера", () => {
  let db: ReturnType<typeof createDb>;

  afterEach(() => {
    db?.close();
  });

  it("без запуска воркера встреча остаётся queued", () => {
    db = createDb(":memory:");
    const meeting = db.createMeeting({
      url: "https://zoom.us/j/1",
      platform: "zoom",
    });
    db.enqueueJob({ meetingId: meeting.id, type: "join" });
    expect(db.getMeeting(meeting.id)?.status).toBe("queued");
  });

  it("прогоняет queued до ready по фикстуре и пишет объявление", async () => {
    db = createDb(":memory:");
    const meeting = db.createMeeting({
      url: "https://telemost.yandex.ru/j/12345678901234",
      platform: "telemost",
    });
    db.enqueueJob({ meetingId: meeting.id, type: "join" });
    const processed = await runOnce(db);
    expect(processed).toBe(true);
    const done = db.getMeeting(meeting.id);
    expect(done?.status).toBe("ready");
    expect(done?.announcementStatus).toBe("объявление (заглушка)");
    expect(done?.source).toBe("stub");
    expect(db.listTranscript(meeting.id).length).toBeGreaterThan(0);
    expect(db.getSummary(meeting.id)?.headline).toBeTruthy();
    expect(db.listActionItems(meeting.id).length).toBeGreaterThan(0);
    expect(db.listWebhookDeliveries()).toEqual([
      expect.objectContaining({
        meetingId: meeting.id,
        status: "skipped",
        detail: "вебхук не настроен",
      }),
    ]);
    expect(await runOnce(db)).toBe(false);
  });

  it("пишет сегмент фикстуры до статуса ready", async () => {
    db = createDb(":memory:");
    const meeting = db.createMeeting({
      url: "https://zoom.us/j/1",
      platform: "zoom",
    });
    db.enqueueJob({ meetingId: meeting.id, type: "join" });
    const statusesAtSave: string[] = [];
    const wrapped = {
      ...db,
      saveTranscript(
        meetingId: string,
        segments: Parameters<typeof db.saveTranscript>[1],
      ) {
        const current = db.getMeeting(meetingId);
        statusesAtSave.push(current?.status ?? "missing");
        expect(current?.status).not.toBe("ready");
        expect(segments.length).toBeGreaterThan(0);
        return db.saveTranscript(meetingId, segments);
      },
    };
    const processed = await runOnce(wrapped);
    expect(processed).toBe(true);
    expect(statusesAtSave.length).toBeGreaterThan(0);
    expect(["recording", "transcribing"]).toContain(statusesAtSave[0]);
    expect(db.getMeeting(meeting.id)?.status).toBe("ready");
    expect(db.listTranscript(meeting.id).length).toBeGreaterThan(0);
  });

  it("живой join без STT сохраняет звук и не подставляет фикстуру standup", async () => {
    db = createDb(":memory:");
    const meeting = db.createMeeting({
      url: "https://zoom.us/j/99988877766",
      platform: "zoom",
    });
    db.enqueueJob({ meetingId: meeting.id, type: "join" });
    const audioPath = `/tmp/pm-live-${meeting.id}.webm`;
    const processed = await runOnce(db, {
      join: async (_meeting, hooks) => {
        await hooks?.onJoined?.({ mode: "live" });
        return { mode: "live", audioPath };
      },
      detectSttEngine: () => null,
      resolveLlmKey: () => "",
    });
    expect(processed).toBe(true);
    const done = db.getMeeting(meeting.id);
    expect(done?.status).toBe("ready");
    expect(done?.source).toBe("live");
    expect(done?.audioPath).toBe(audioPath);
    const transcript = db.listTranscript(meeting.id);
    expect(transcript).toHaveLength(1);
    expect(transcript[0]?.text).toBe(LIVE_AUDIO_PENDING_TEXT);
    expect(transcript.some((row) => /standup/i.test(row.text))).toBe(false);
    const summary = db.getSummary(meeting.id);
    expect(summary?.headline).toBe(LIVE_AUDIO_PENDING_TEXT);
    expect(summary?.headline).not.toMatch(/hotfix/i);
    expect(db.listActionItems(meeting.id)).toEqual([]);
  });

  it("падение join ставит error и даёт обработать следующую встречу", async () => {
    db = createDb(":memory:");
    const first = db.createMeeting({
      url: "https://zoom.us/j/11122233344",
      platform: "zoom",
    });
    db.enqueueJob({ meetingId: first.id, type: "join" });
    await expect(
      runOnce(db, {
        join: async () => {
          throw new Error("нет chromium");
        },
      }),
    ).rejects.toThrow(/нет chromium/);
    expect(db.getMeeting(first.id)?.status).toBe("error");
    const second = db.createMeeting({
      url: "https://zoom.us/j/55566677788",
      platform: "zoom",
    });
    db.enqueueJob({ meetingId: second.id, type: "join" });
    expect(await runOnce(db)).toBe(true);
    expect(db.getMeeting(second.id)?.status).toBe("ready");
  });

  it("живой join при падении whisper ставит error, а не заглушку pending", async () => {
    db = createDb(":memory:");
    const meeting = db.createMeeting({
      url: "https://zoom.us/j/99988877766",
      platform: "zoom",
    });
    db.enqueueJob({ meetingId: meeting.id, type: "join" });
    await expect(
      runOnce(db, {
        join: async (_item, hooks) => {
          await hooks?.onJoined?.({ mode: "live" });
          return { mode: "live", audioPath: "/tmp/pm-missing-audio.wav" };
        },
        detectSttEngine: () => ({
          kind: "whisper-cli",
          bin: "/tmp/pm-assistant-missing-whisper",
        }),
        resolveLlmKey: () => "",
      }),
    ).rejects.toThrow();
    const done = db.getMeeting(meeting.id);
    expect(done?.status).toBe("error");
    expect(done?.error).toMatch(/whisper|ENOENT|spawn/i);
    expect(db.listTranscript(meeting.id)).toEqual([]);
  });

  it("задание transcribe требует whisper и файл звука", async () => {
    db = createDb(":memory:");
    const meeting = db.createMeeting({
      url: "https://zoom.us/j/99988877766",
      platform: "zoom",
    });
    db.updateMeetingStatus(meeting.id, "joining");
    db.updateMeetingStatus(meeting.id, "recording", {
      audioPath: "/tmp/pm-live.wav",
      source: "live",
    });
    db.updateMeetingStatus(meeting.id, "transcribing");
    db.updateMeetingStatus(meeting.id, "summarizing");
    db.updateMeetingStatus(meeting.id, "ready");
    db.enqueueJob({ meetingId: meeting.id, type: "transcribe" });
    await expect(
      runOnce(db, { detectSttEngine: () => null }),
    ).rejects.toThrow(/нет whisper/);
    expect(db.getMeeting(meeting.id)?.status).toBe("error");
  });

  it("join при audio_path не входит в звонок, а ставит расшифровку", async () => {
    db = createDb(":memory:");
    const meeting = db.createMeeting({
      url: "https://zoom.us/j/99988877766",
      platform: "zoom",
    });
    db.updateMeetingStatus(meeting.id, "joining");
    db.updateMeetingStatus(meeting.id, "recording", {
      audioPath: "/tmp/pm-live.wav",
      source: "live",
    });
    db.updateMeetingStatus(meeting.id, "error", {
      error: "llm ответил статусом 429",
    });
    db.enqueueJob({ meetingId: meeting.id, type: "join" });
    let joined = 0;
    await expect(
      runOnce(db, {
        join: async () => {
          joined += 1;
          return { mode: "live", audioPath: "/tmp/pm-live.wav" };
        },
        detectSttEngine: () => null,
      }),
    ).rejects.toThrow(/нет whisper/);
    expect(joined).toBe(0);
    expect(
      db.listJobs().some((job) => job.type === "join" && job.status === "running"),
    ).toBe(false);
  });

  it("живой join при 429 llm сохраняет расшифровку и ставит ready", async () => {
    db = createDb(":memory:");
    const meeting = db.createMeeting({
      url: "https://zoom.us/j/99988877766",
      platform: "zoom",
    });
    db.enqueueJob({ meetingId: meeting.id, type: "join" });
    const prevFetch = globalThis.fetch;
    globalThis.fetch = (async () =>
      new Response("rate limited", {
        status: 429,
        headers: { "retry-after": "0" },
      })) as typeof fetch;
    try {
      const processed = await runOnce(db, {
        join: async (_item, hooks) => {
          await hooks?.onJoined?.({ mode: "live" });
          return { mode: "live", audioPath: "/tmp/pm-live.wav" };
        },
        transcribe: async () => ({
          mode: "live",
          segments: [
            {
              speaker: "Спикер 1",
              startedAtMs: 0,
              endedAtMs: 2000,
              text: "Начинаем ежедневный митинг.",
            },
          ],
        }),
        resolveLlmKey: () => "sk-test",
      });
      expect(processed).toBe(true);
      const done = db.getMeeting(meeting.id);
      expect(done?.status).toBe("ready");
      expect(db.listTranscript(meeting.id)[0]?.text).toMatch(/митинг/);
      expect(db.getSummary(meeting.id)?.decisions).toMatch(/429/);
    } finally {
      globalThis.fetch = prevFetch;
    }
  });
});
