import type { ActionItem } from "../../shared/types.ts";
import type { Db } from "../../db/index.ts";

export const ASANA_TASKS_URL = "https://app.asana.com/api/1.0/tasks";

export type AsanaDispatchMode = "queued" | "sent";

export type AsanaTaskInput = {
  id: string;
  title: string;
  assignee: string | null;
  dueAt: string | null;
};

export type AsanaDispatchResult = {
  mode: AsanaDispatchMode;
  notice: string;
  itemIds: string[];
};

export type AsanaAdapter = {
  hasToken: boolean;
  dispatch(items: AsanaTaskInput[]): Promise<AsanaDispatchResult>;
};

const NO_TOKEN_NOTICE =
  "Нет ключа ASANA_PAT. Задачи помечены к отправке.";
const SENT_NOTICE = "Задачи отправлены в Asana.";
const FAIL_NOTICE =
  "Не удалось отправить в Asana. Задачи помечены к отправке.";

export function resolveAsanaPat(explicit?: string | null): string {
  const raw = explicit !== undefined ? explicit : process.env.ASANA_PAT;
  return raw?.trim() ?? "";
}

function taskPayload(item: AsanaTaskInput, projectGid: string) {
  const data: Record<string, unknown> = {
    name: item.title,
  };
  if (item.assignee) {
    data.notes = `Ответственный: ${item.assignee}`;
  }
  if (item.dueAt) {
    data.due_on = item.dueAt.slice(0, 10);
  }
  if (projectGid) {
    data.projects = [projectGid];
  }
  return { data };
}

export function createAsanaAdapter(opts?: {
  token?: string | null;
  projectGid?: string;
  fetchImpl?: typeof fetch;
}): AsanaAdapter {
  const token = resolveAsanaPat(opts?.token);
  const projectGid = opts?.projectGid?.trim() ?? "";
  const fetchImpl = opts?.fetchImpl ?? globalThis.fetch.bind(globalThis);

  if (!token) {
    return {
      hasToken: false,
      async dispatch(items) {
        return {
          mode: "queued",
          notice: NO_TOKEN_NOTICE,
          itemIds: items.map((item) => item.id),
        };
      },
    };
  }

  return {
    hasToken: true,
    async dispatch(items) {
      for (const item of items) {
        const response = await fetchImpl(ASANA_TASKS_URL, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(taskPayload(item, projectGid)),
        });
        if (!response.ok) {
          throw new Error(`Asana ответила ${response.status}`);
        }
      }
      return {
        mode: "sent",
        notice: SENT_NOTICE,
        itemIds: items.map((item) => item.id),
      };
    },
  };
}

export async function dispatchActionItems(
  db: Db,
  items: ActionItem[],
  opts?: {
    token?: string | null;
    projectGid?: string;
    fetchImpl?: typeof fetch;
  },
): Promise<AsanaDispatchResult> {
  const ids = items.map((item) => item.id);
  if (ids.length === 0) {
    return { mode: "queued", notice: NO_TOKEN_NOTICE, itemIds: [] };
  }
  const adapter = createAsanaAdapter({
    token: opts?.token,
    projectGid: opts?.projectGid ?? db.getSettings().asanaProjectLabel,
    fetchImpl: opts?.fetchImpl,
  });
  try {
    const result = await adapter.dispatch(items);
    if (result.mode === "sent") {
      db.markActionItemsSentToAsana(ids);
    } else {
      db.markActionItemsQueuedForAsana(ids);
    }
    return result;
  } catch {
    db.markActionItemsQueuedForAsana(ids);
    return { mode: "queued", notice: FAIL_NOTICE, itemIds: ids };
  }
}

export async function maybeAutoSendAsana(
  db: Db,
  meetingId: string,
  opts?: {
    token?: string | null;
    fetchImpl?: typeof fetch;
  },
): Promise<AsanaDispatchResult | null> {
  if (!db.getSettings().asanaAutoSend) {
    return null;
  }
  const pending = db
    .listActionItems(meetingId)
    .filter((item) => item.asanaState === "none");
  if (pending.length === 0) {
    return null;
  }
  return dispatchActionItems(db, pending, opts);
}
