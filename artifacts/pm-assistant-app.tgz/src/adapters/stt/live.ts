import { spawn } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, extname, join } from "node:path";
import type { SttEngine, Transcript, TranscribeOptions } from "./index.ts";

type WhisperSegment = {
  start?: number;
  end?: number;
  text?: string;
};

type WhisperJson = {
  segments?: WhisperSegment[];
};

export async function liveTranscribe(
  audioPath: string,
  options: TranscribeOptions,
  engine: SttEngine,
): Promise<Transcript> {
  const tmp = await mkdtemp(join(tmpdir(), "pm-stt-"));
  try {
    await runWhisper(engine.bin, audioPath, tmp, options.languageHint);
    const jsonPath = join(tmp, `${basename(audioPath, extname(audioPath))}.json`);
    const data = JSON.parse(await readFile(jsonPath, "utf8")) as WhisperJson;
    const segments = (data.segments ?? []).map((segment) => ({
      speaker: "Спикер 1",
      startedAtMs: Math.round((segment.start ?? 0) * 1000),
      endedAtMs:
        segment.end == null ? null : Math.round(segment.end * 1000),
      text: String(segment.text ?? "").trim(),
    }));
    return { mode: "live", segments };
  } finally {
    await rm(tmp, { recursive: true, force: true });
  }
}

function runWhisper(
  bin: string,
  audioPath: string,
  outputDir: string,
  languageHint?: string,
): Promise<void> {
  const args = [
    audioPath,
    "--output_format",
    "json",
    "--output_dir",
    outputDir,
    "--verbose",
    "False",
  ];
  if (languageHint) {
    args.push("--language", languageHint);
  }
  return new Promise((resolve, reject) => {
    const child = spawn(bin, args, {
      stdio: ["ignore", "pipe", "pipe"],
      env: {
        ...process.env,
        LD_LIBRARY_PATH: [
          "/usr/local/lib",
          process.env.LD_LIBRARY_PATH ?? "",
        ]
          .filter(Boolean)
          .join(":"),
      },
    });
    let stderr = "";
    child.stderr?.on("data", (chunk: Buffer) => {
      stderr += chunk.toString("utf8");
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) {
        resolve();
        return;
      }
      const detail = stderr.trim().slice(-1500);
      reject(
        new Error(
          detail
            ? `whisper завершился с кодом ${code}: ${detail}`
            : `whisper завершился с кодом ${code}`,
        ),
      );
    });
  });
}
