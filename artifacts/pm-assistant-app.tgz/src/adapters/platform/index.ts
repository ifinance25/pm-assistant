export { detectPlatform } from "./detect.ts";
export {
  createJoinAdapter,
  MeetAdapter,
  TelemostAdapter,
  ZoomAdapter,
  type JoinAdapter,
  type JoinHooks,
  type JoinResult,
} from "./join.ts";
