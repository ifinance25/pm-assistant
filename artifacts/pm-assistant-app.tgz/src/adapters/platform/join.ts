import type { Meeting } from "../../shared/types.ts";
import { joinZoomMeeting, hasZoomSdkCredentials } from "./zoom-bot.ts";

export type JoinResult = {
  mode: "live" | "stub";
  audioPath: string | null;
};

export type JoinHooks = {
  onJoined?: (info: { mode: "live" | "stub" }) => void | Promise<void>;
};

export type JoinAdapter = {
  join(meeting: Meeting, hooks?: JoinHooks): Promise<JoinResult>;
};

const STUB: JoinResult = { mode: "stub", audioPath: null };

async function stubJoin(hooks?: JoinHooks): Promise<JoinResult> {
  await hooks?.onJoined?.({ mode: "stub" });
  return STUB;
}

export const ZoomAdapter: JoinAdapter = {
  async join(meeting, hooks) {
    if (!hasZoomSdkCredentials()) {
      return stubJoin(hooks);
    }
    return joinZoomMeeting(meeting, { onJoined: hooks?.onJoined });
  },
};

export const MeetAdapter: JoinAdapter = {
  join(_meeting, hooks) {
    return stubJoin(hooks);
  },
};

export const TelemostAdapter: JoinAdapter = {
  join(_meeting, hooks) {
    return stubJoin(hooks);
  },
};

export function createJoinAdapter(): JoinAdapter {
  return {
    async join(meeting: Meeting, hooks?: JoinHooks): Promise<JoinResult> {
      if (meeting.platform === "zoom") {
        return ZoomAdapter.join(meeting, hooks);
      }
      if (meeting.platform === "meet") {
        return MeetAdapter.join(meeting, hooks);
      }
      return TelemostAdapter.join(meeting, hooks);
    },
  };
}
