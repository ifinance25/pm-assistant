import { describe, expect, it, vi } from "vitest";
import { createLlmAdapter } from "./index.ts";
import { createSttAdapter } from "../stt/index.ts";

describe("llm", () => {
  it("summarize возвращает headline, decisions, risks, nextStep и задачи кто/что/когда", async () => {
    const stt = createSttAdapter({ detectEngine: () => null });
    const transcript = await stt.transcribe("fixtures/demo.wav", {
      languageHint: "ru",
    });
    const llm = createLlmAdapter({ apiKey: "" });
    const result = await llm.summarize(transcript);

    expect(result.mode).toBe("stub");
    expect(result.summary.headline).toMatch(/hotfix/);
    expect(result.summary.decisions).toMatch(/changelog/);
    expect(result.summary.risks).toMatch(/deadline/);
    expect(result.summary.nextStep).toMatch(/понедельник/);
    expect(result.actionItems).toEqual([
      {
        assignee: "Иван Смирнов",
        title: "Подготовить hotfix для API gateway",
        dueAt: "2026-09-05",
        timecodeMs: 8500,
      },
      {
        assignee: "Мария Козлова",
        title: "Написать changelog и проверить feature flag на staging",
        dueAt: "2026-09-08",
        timecodeMs: 18000,
      },
    ]);
  });

  it("пустой OPENAI_API_KEY даёт stub и не падает, непустой ключ даёт live", async () => {
    const stub = createLlmAdapter({ apiKey: "" });
    expect(stub.mode).toBe("stub");
    const transcript = {
      mode: "stub" as const,
      segments: [
        {
          speaker: "Анна Петрова",
          startedAtMs: 0,
          endedAtMs: 1000,
          text: "standup",
        },
      ],
    };
    await expect(stub.summarize(transcript)).resolves.toMatchObject({
      mode: "stub",
    });

    expect(createLlmAdapter({ apiKey: "sk-test" }).mode).toBe("live");
  });

  it("непустой CLAUDE_CODE_OAUTH_TOKEN без явного apiKey даёт live", () => {
    const prev = process.env.CLAUDE_CODE_OAUTH_TOKEN;
    process.env.CLAUDE_CODE_OAUTH_TOKEN = "oauth-test-token";
    try {
      expect(createLlmAdapter().mode).toBe("live");
    } finally {
      if (prev === undefined) {
        delete process.env.CLAUDE_CODE_OAUTH_TOKEN;
      } else {
        process.env.CLAUDE_CODE_OAUTH_TOKEN = prev;
      }
    }
  });

  it("при 429 повторяет запрос и затем возвращает JSON", async () => {
    const { liveSummarize, LlmHttpError } = await import("./live.ts");
    const okBody = {
      choices: [
        {
          message: {
            content: JSON.stringify({
              summary: {
                headline: "Итог",
                decisions: "Решили",
                risks: "",
                nextStep: "Дальше",
              },
              actionItems: [],
            }),
          },
        },
      ],
    };
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(new Response("limit", { status: 429 }))
      .mockResolvedValueOnce(
        new Response(JSON.stringify(okBody), { status: 200 }),
      );
    vi.stubGlobal("fetch", fetchMock);
    try {
      const result = await liveSummarize(
        {
          mode: "live",
          segments: [
            {
              speaker: "Анна",
              startedAtMs: 0,
              endedAtMs: 1000,
              text: "standup",
            },
          ],
        },
        "sk-test",
      );
      expect(result.summary.headline).toBe("Итог");
      expect(fetchMock).toHaveBeenCalledTimes(2);
    } finally {
      vi.unstubAllGlobals();
    }
    expect(new LlmHttpError(429).status).toBe(429);
  });
});
