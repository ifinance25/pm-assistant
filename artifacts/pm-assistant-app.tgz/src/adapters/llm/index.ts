import type { Transcript } from "../stt/index.ts";
import { liveSummarize, liveSummarizeClaude } from "./live.ts";
import { stubSummarize } from "./stub.ts";

export type LlmMode = "live" | "stub";

export type MeetingSummary = {
  headline: string;
  decisions: string;
  risks: string;
  nextStep: string;
};

export type ActionItemDraft = {
  assignee: string | null;
  title: string;
  dueAt: string | null;
  timecodeMs: number | null;
};

export type SummarizeResult = {
  mode: LlmMode;
  summary: MeetingSummary;
  actionItems: ActionItemDraft[];
};

export type LlmAdapter = {
  mode: LlmMode;
  summarize(transcript: Transcript): Promise<SummarizeResult>;
};

export function resolveClaudeOauthToken(explicit?: string | null): string {
  const raw =
    explicit !== undefined ? explicit : process.env.CLAUDE_CODE_OAUTH_TOKEN;
  return raw?.trim() ?? "";
}

export function resolveApiKey(explicit?: string | null): string {
  const raw = explicit !== undefined ? explicit : process.env.OPENAI_API_KEY;
  return raw?.trim() ?? "";
}

export function createLlmAdapter(opts?: {
  apiKey?: string | null;
  oauthToken?: string | null;
}): LlmAdapter {
  const oauthExplicit = opts && "oauthToken" in opts;
  const apiExplicit = opts && "apiKey" in opts;
  const oauth = resolveClaudeOauthToken(
    oauthExplicit ? opts.oauthToken : undefined,
  );
  const apiKey = resolveApiKey(apiExplicit ? opts.apiKey : undefined);

  if (apiExplicit && !oauthExplicit) {
    if (!apiKey) {
      return { mode: "stub", summarize: stubSummarize };
    }
    return {
      mode: "live",
      summarize: (transcript) => liveSummarize(transcript, apiKey),
    };
  }

  if (oauth) {
    return {
      mode: "live",
      summarize: (transcript) => liveSummarizeClaude(transcript, oauth),
    };
  }
  if (apiKey) {
    return {
      mode: "live",
      summarize: (transcript) => liveSummarize(transcript, apiKey),
    };
  }
  return { mode: "stub", summarize: stubSummarize };
}

export function summarize(transcript: Transcript): Promise<SummarizeResult> {
  return createLlmAdapter().summarize(transcript);
}
