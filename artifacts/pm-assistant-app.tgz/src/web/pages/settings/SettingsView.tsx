import type { RecordingMode, Settings } from "../../../shared/types.ts";

const MODES: { id: RecordingMode; title: string; short: string; text: string }[] =
  [
    {
      id: "text",
      title: "Только текст",
      short: "только текст",
      text: "Без сохранения звука. Транскрипт и резюме остаются в базе.",
    },
    {
      id: "local_audio",
      title: "Локальный звук",
      short: "локальный звук",
      text: "Аудио остаётся на этом Mac, в облако не уходит.",
    },
    {
      id: "full",
      title: "Полная запись",
      short: "полная запись",
      text: "Звук, транскрипт, резюме и решения. Удалять вручную.",
    },
  ];

const CALENDARS = [
  { name: "Google Календарь", note: "не подключено" },
  { name: "Outlook", note: "не подключено" },
  { name: "Локальный список", note: "из SQLite" },
];

type SettingsViewProps = {
  settings: Settings;
  saving?: boolean;
  restartDialogOpen?: boolean;
  restarting?: boolean;
  onRecordingModeChange?: (mode: RecordingMode) => void;
  onAsanaAutoSendChange?: (value: boolean) => void;
  onAsanaProjectLabelChange?: (value: string) => void;
  onWebhookUrlChange?: (value: string) => void;
  onSave?: () => void;
  onRestartClick?: () => void;
  onRestartConfirm?: () => void;
  onRestartCancel?: () => void;
};

export function SettingsView({
  settings,
  saving = false,
  restartDialogOpen = false,
  restarting = false,
  onRecordingModeChange,
  onAsanaAutoSendChange,
  onAsanaProjectLabelChange,
  onSave,
  onRestartClick,
  onRestartConfirm,
  onRestartCancel,
}: SettingsViewProps) {
  const modeShort =
    MODES.find((mode) => mode.id === settings.recordingModeDefault)?.short ??
    "только текст";
  const asanaShort = settings.asanaAutoSend ? "очередь" : "выключено";
  const nowText = `Запись: ${modeShort}. Asana: ${asanaShort}. Календарь: локальный список. Язык: русский. Команда и биллинг скрыты.`;

  return (
    <section className="settings">
      <header className="settings__top">
        <h1 className="settings__title">Настройки</h1>
        <p className="settings__lead">
          Режим записи, Asana и локальный список встреч
        </p>
      </header>
      <div className="settings__body">
        <div className="settings__main">
          <section className="settings__panel">
            <div className="settings__panel-head">
              <h2 className="settings__panel-title">Запись и интеграции</h2>
              <button
                type="button"
                className="settings__save"
                onClick={() => onSave?.()}
                disabled={saving}
              >
                Сохранить
              </button>
            </div>
            <fieldset className="settings__modes">
              <legend>Режим записи по умолчанию</legend>
              {MODES.map((mode) => {
                const selected = settings.recordingModeDefault === mode.id;
                return (
                  <label
                    key={mode.id}
                    className={
                      selected
                        ? "settings__mode settings__mode--active"
                        : "settings__mode"
                    }
                  >
                    <input
                      type="radio"
                      name="recordingModeDefault"
                      value={mode.id}
                      checked={selected}
                      onChange={() => onRecordingModeChange?.(mode.id)}
                    />
                    <span
                      className={
                        selected
                          ? "settings__dot settings__dot--on"
                          : "settings__dot"
                      }
                      aria-hidden="true"
                    />
                    <span>
                      <strong>{mode.title}</strong>
                      <span>{mode.text}</span>
                    </span>
                  </label>
                );
              })}
            </fieldset>
            <section className="settings__asana">
              <label className="settings__toggle">
                Автоотправка в Asana
                <input
                  type="checkbox"
                  className="settings__switch"
                  checked={settings.asanaAutoSend}
                  onChange={(event) =>
                    onAsanaAutoSendChange?.(event.currentTarget.checked)
                  }
                />
              </label>
              <p className="settings__hint">
                Когда встреча готова, тумблер ставит задачи в очередь отправки.
                Токен задаётся в ASANA_PAT, значение в интерфейс не попадает.
              </p>
              <div className="settings__project">
                <span>
                  {`Проект: ${settings.asanaProjectLabel.trim() || "PM Assistant / встречи"}`}
                </span>
                <label className="settings__change">
                  изменить
                  <input
                    type="text"
                    value={settings.asanaProjectLabel}
                    placeholder="PM Assistant / встречи"
                    onChange={(event) =>
                      onAsanaProjectLabelChange?.(event.currentTarget.value)
                    }
                  />
                </label>
              </div>
            </section>
            <section className="settings__stt">
              <h3 className="settings__subhead">Распознавание речи</h3>
              <p className="settings__hint">
                Сейчас: заглушка STT. Локальный движок не найден. Карточки
                встреч это показывают.
              </p>
            </section>
          </section>
          <section className="settings__panel settings__bot">
            <h2 className="settings__panel-title">Сервис бота</h2>
            <p className="settings__hint">
              Зависшие встречи снимутся, контейнеры и воркер на сервере
              перезапустятся.
            </p>
            <button
              type="button"
              className="settings__restart"
              onClick={() => onRestartClick?.()}
              disabled={restarting}
            >
              Перезапустить бота
            </button>
          </section>
        </div>
        <aside className="settings__aside">
          <section className="settings__calendars">
            <h2>Календари</h2>
            <p className="settings__hint">
              Живые Google и Apple в этой версии недоступны. Список встреч
              берётся из базы.
            </p>
            <ul>
              {CALENDARS.map((item) => (
                <li key={item.name}>
                  <strong>{item.name}</strong>
                  <span className="settings__status">{item.note}</span>
                </li>
              ))}
            </ul>
            <button type="button" className="settings__connect">
              Подключить календарь
            </button>
          </section>
          <section className="settings__now">
            <h2>Сейчас включено</h2>
            <p>{nowText}</p>
          </section>
          <section className="settings__policy">
            <h2>Про режим «только текст»</h2>
            <p>
              Звук не сохраняется. В базе остаются транскрипт, резюме и задачи.
            </p>
          </section>
        </aside>
      </div>
      {restartDialogOpen ? (
        <div className="settings__dialog-backdrop">
          <div
            className="settings__dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="settings-restart-title"
          >
            <h2 id="settings-restart-title">Нужно ли перезапустить бота?</h2>
            <div className="settings__dialog-actions">
              <button
                type="button"
                className="settings__dialog-no"
                onClick={() => onRestartCancel?.()}
                disabled={restarting}
              >
                Нет
              </button>
              <button
                type="button"
                className="settings__dialog-yes"
                onClick={() => onRestartConfirm?.()}
                disabled={restarting}
              >
                Да
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </section>
  );
}
