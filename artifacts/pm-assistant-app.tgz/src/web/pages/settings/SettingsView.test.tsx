import { renderToString } from "react-dom/server";
import { describe, expect, it } from "vitest";
import type { Settings } from "../../../shared/types.ts";
import { SettingsView } from "./SettingsView.tsx";

const settings: Settings = {
  recordingModeDefault: "text",
  asanaProjectLabel: "",
  asanaAutoSend: false,
  webhookUrl: "",
  workerHeartbeatAt: null,
};

describe("SettingsView", () => {
  it("показывает заголовок Настройки и подпись про режим записи, Asana и локальный список", () => {
    const html = renderToString(<SettingsView settings={settings} />);
    expect(html).toContain("Настройки");
    expect(html).toContain("Режим записи, Asana и локальный список встреч");
    expect(html).not.toContain("\u2014");
  });

  it("показывает три режима записи крупными рядами, выбранный с терракотовой точкой", () => {
    const html = renderToString(<SettingsView settings={settings} />);
    expect(html).toContain("Только текст");
    expect(html).toContain("Локальный звук");
    expect(html).toContain("Полная запись");
    expect(html).toContain("settings__mode--active");
    expect(html).toContain("settings__dot");
    expect(html).toContain("Без сохранения звука. Транскрипт и резюме остаются в базе.");
    expect(html).toContain("Аудио остаётся на этом Mac, в облако не уходит.");
    expect(html).toContain("Звук, транскрипт, резюме и решения. Удалять вручную.");
  });

  it("показывает тумблер автоотправки Asana и подпись про PAT", () => {
    const html = renderToString(<SettingsView settings={settings} />);
    expect(html).toContain("Автоотправка в Asana");
    expect(html).toContain("ASANA_PAT");
    expect(html).toContain("Проект: PM Assistant / встречи");
    expect(html).toContain("изменить");
    expect(html).not.toContain("asana.com");
  });

  it("показывает календарные карточки как заглушку без OAuth", () => {
    const html = renderToString(<SettingsView settings={settings} />);
    expect(html).toContain("Календари");
    expect(html).toContain("Google Календарь");
    expect(html).toContain("Outlook");
    expect(html).toContain("Локальный список");
    expect(html).toContain("не подключено");
    expect(html).toContain("из SQLite");
    expect(html).toContain("Подключить календарь");
    expect(html).not.toContain("accounts.google.com");
    expect(html).not.toContain("login.microsoftonline.com");
    expect(html).not.toContain("oauth");
  });

  it("показывает тёмную сводку Сейчас включено и что Команда и Биллинг скрыты", () => {
    const html = renderToString(<SettingsView settings={settings} />);
    expect(html).toContain("Сейчас включено");
    expect(html).toContain("settings__now");
    expect(html).toContain(
      "Запись: только текст. Asana: выключено. Календарь: локальный список. Язык: русский. Команда и биллинг скрыты.",
    );
    expect(html).not.toContain("\u2014");
  });

  it("показывает кнопку перезапуска бота и скрывает диалог", () => {
    const html = renderToString(<SettingsView settings={settings} />);
    expect(html).toContain("Сервис бота");
    expect(html).toContain(
      "Зависшие встречи снимутся, контейнеры и воркер на сервере перезапустятся.",
    );
    expect(html).toContain("Перезапустить бота");
    expect(html).not.toContain("Нужно ли перезапустить бота?");
    expect(html).not.toContain("role=\"dialog\"");
    expect(html).not.toContain("\u2014");
  });

  it("показывает диалог с кнопками Да и Нет, когда он открыт", () => {
    const html = renderToString(
      <SettingsView settings={settings} restartDialogOpen />,
    );
    expect(html).toContain("Нужно ли перезапустить бота?");
    expect(html).toContain("Да");
    expect(html).toContain("Нет");
    expect(html).toContain("role=\"dialog\"");
    expect(html).toContain("aria-modal");
    expect(html).toContain("aria-labelledby=\"settings-restart-title\"");
    expect(html).not.toContain("\u2014");
  });
});
