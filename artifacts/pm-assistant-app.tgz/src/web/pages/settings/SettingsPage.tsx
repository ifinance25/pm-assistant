import { useEffect, useState } from "react";
import type { RecordingMode, Settings } from "../../../shared/types.ts";
import { SettingsView } from "./SettingsView.tsx";
import "./settings.css";

export function SettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [restartDialogOpen, setRestartDialogOpen] = useState(false);
  const [restarting, setRestarting] = useState(false);

  useEffect(() => {
    void fetch("/api/settings")
      .then((res) => {
        if (!res.ok) {
          throw new Error("load");
        }
        return res.json() as Promise<Settings>;
      })
      .then((body) => {
        setSettings(body);
        setError(null);
      })
      .catch(() => {
        setError("Не удалось загрузить настройки");
      });
  }, []);

  async function onRestartConfirm(): Promise<void> {
    setRestarting(true);
    try {
      const res = await fetch("/api/bot/restart", { method: "POST" });
      if (!res.ok) {
        throw new Error("restart");
      }
      const body = (await res.json()) as {
        meetingsCleared?: number;
        jobsFailed?: number;
        containersRemoved?: number;
        workerRestarted?: boolean;
      };
      const worker = body.workerRestarted
        ? "воркер перезапущен"
        : "воркер на этой машине не трогали";
      setNotice(
        `Бот сброшен: встреч снято ${body.meetingsCleared ?? 0}, заданий ${body.jobsFailed ?? 0}, контейнеров ${body.containersRemoved ?? 0}. ${worker}.`,
      );
      setError(null);
      setRestartDialogOpen(false);
    } catch {
      setError("Не удалось перезапустить бота");
      setNotice(null);
      setRestartDialogOpen(false);
    } finally {
      setRestarting(false);
    }
  }

  async function onSave(): Promise<void> {
    if (!settings) {
      return;
    }
    setSaving(true);
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          recordingModeDefault: settings.recordingModeDefault,
          asanaAutoSend: settings.asanaAutoSend,
          asanaProjectLabel: settings.asanaProjectLabel,
          webhookUrl: settings.webhookUrl,
        }),
      });
      if (!res.ok) {
        throw new Error("save");
      }
      setSettings((await res.json()) as Settings);
      setError(null);
    } catch {
      setError("Не удалось сохранить настройки");
    } finally {
      setSaving(false);
    }
  }

  if (!settings) {
    return (
      <section className="settings">
        <h1 className="settings__title">{error ?? "Загрузка настроек..."}</h1>
      </section>
    );
  }

  return (
    <>
      {error ? <p className="settings__error">{error}</p> : null}
      {notice ? <p className="settings__notice">{notice}</p> : null}
      <SettingsView
        settings={settings}
        saving={saving}
        restartDialogOpen={restartDialogOpen}
        restarting={restarting}
        onRecordingModeChange={(mode: RecordingMode) =>
          setSettings((prev) =>
            prev ? { ...prev, recordingModeDefault: mode } : prev,
          )
        }
        onAsanaAutoSendChange={(value) =>
          setSettings((prev) =>
            prev ? { ...prev, asanaAutoSend: value } : prev,
          )
        }
        onAsanaProjectLabelChange={(value) =>
          setSettings((prev) =>
            prev ? { ...prev, asanaProjectLabel: value } : prev,
          )
        }
        onWebhookUrlChange={(value) =>
          setSettings((prev) => (prev ? { ...prev, webhookUrl: value } : prev))
        }
        onSave={() => void onSave()}
        onRestartClick={() => setRestartDialogOpen(true)}
        onRestartCancel={() => setRestartDialogOpen(false)}
        onRestartConfirm={() => void onRestartConfirm()}
      />
    </>
  );
}
