import { renderToString } from "react-dom/server";
import { MemoryRouter } from "react-router-dom";
import { describe, expect, it } from "vitest";
import type { Meeting } from "../../../shared/types.ts";
import { HomeView } from "./HomeView.tsx";

const upcoming: Meeting = {
  id: "m-up",
  url: "https://zoom.us/j/111",
  platform: "zoom",
  title: "Синк по roadmap Q4",
  status: "queued",
  recordingMode: "text",
  startedAt: "2026-09-04T07:30:00.000Z",
  endedAt: null,
  error: null,
  announcementStatus: null,
  source: "stub",
  audioPath: null,
};

const ready: Meeting = {
  id: "m-ready",
  url: "https://meet.google.com/aaa-bbbb-ccc",
  platform: "meet",
  title: "Встреча по onboarding",
  status: "ready",
  recordingMode: "text",
  startedAt: "2026-09-03T10:00:00.000Z",
  endedAt: "2026-09-03T10:47:00.000Z",
  error: null,
  announcementStatus: null,
  source: "stub",
  audioPath: null,
};

function renderHome(meetings: Meeting[]) {
  return renderToString(
    <MemoryRouter>
      <HomeView
        meetings={meetings}
        storage={{ meetingCount: meetings.length, usedBytes: 0 }}
        url=""
        error={null}
        notice={null}
        busy={false}
        onUrlChange={() => undefined}
        onSubmit={() => undefined}
        onSendBot={() => undefined}
      />
    </MemoryRouter>,
  );
}

describe("HomeView", () => {
  it("рендерит ключевые русские подписи макета", () => {
    const html = renderHome([upcoming, ready]);
    expect(html).toContain("Главная");
    expect(html).toContain("бот готов к записи");
    expect(html).toContain("Отправить бота");
    expect(html).toContain("Открыть звонок");
    expect(html).toContain("Запустить запись вручную");
    expect(html).toContain("ссылка на встречу");
    expect(html).toContain("Бот");
    expect(html).toContain("Ближайшие звонки");
    expect(html).toContain("Последние расшифровки");
    expect(html).toContain("Хранилище");
    expect(html).toContain("Синк по roadmap Q4");
    expect(html).toContain("Встреча по onboarding");
    expect(html).toContain("весь календарь");
    expect(html).not.toContain("\u2014");
    expect(html).not.toContain("#0062FF");
  });
});
