import { FormEvent } from "react";
import { Link } from "react-router-dom";
import type { Meeting, MeetingStatus, Platform } from "../../../shared/types.ts";
import "./home.css";

export type StorageStats = {
  meetingCount: number;
  usedBytes: number;
};

export type HomeViewProps = {
  meetings: Meeting[];
  storage: StorageStats;
  url: string;
  error: string | null;
  notice: string | null;
  busy: boolean;
  onUrlChange: (url: string) => void;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
  onSendBot: (meetingUrl: string) => void;
};

const STATUS_LABEL: Record<MeetingStatus, string> = {
  queued: "В очереди",
  joining: "Входит",
  recording: "Идёт запись",
  transcribing: "Расшифровка",
  summarizing: "Резюме",
  ready: "Готово",
  error: "Ошибка",
};

const PLATFORM_LABEL: Record<Platform, string> = {
  zoom: "Zoom",
  meet: "Google Meet",
  telemost: "Телемост",
  unknown: "Платформа",
};

const LIVE_STATUS: MeetingStatus[] = ["queued", "joining", "recording"];

function meetingWord(count: number): string {
  const n10 = count % 10;
  const n100 = count % 100;
  if (n10 === 1 && n100 !== 11) {
    return "встреча";
  }
  if (n10 >= 2 && n10 <= 4 && (n100 < 12 || n100 > 14)) {
    return "встречи";
  }
  return "встреч";
}

function fileWord(count: number): string {
  const n10 = count % 10;
  const n100 = count % 100;
  if (n10 === 1 && n100 !== 11) {
    return "файл";
  }
  if (n10 >= 2 && n10 <= 4 && (n100 < 12 || n100 > 14)) {
    return "файла";
  }
  return "файлов";
}

function minuteWord(count: number): string {
  const n10 = count % 10;
  const n100 = count % 100;
  if (n10 === 1 && n100 !== 11) {
    return "минуту";
  }
  if (n10 >= 2 && n10 <= 4 && (n100 < 12 || n100 > 14)) {
    return "минуты";
  }
  return "минут";
}

function formatBytes(bytes: number): string {
  if (bytes === 0) {
    return "0 Б";
  }
  const units = ["Б", "КБ", "МБ", "ГБ"];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value.toFixed(unit === 0 ? 0 : 1)} ${units[unit]}`;
}

function storagePercent(usedBytes: number): number {
  const cap = 2 * 1024 * 1024 * 1024;
  return Math.min(100, Math.round((usedBytes / cap) * 100));
}

function meetingTitle(meeting: Meeting): string {
  if (meeting.title) {
    return meeting.title;
  }
  return `Встреча ${PLATFORM_LABEL[meeting.platform]}`;
}

function formatClock(iso: string | null): string | null {
  if (!iso) {
    return null;
  }
  return new Date(iso).toLocaleTimeString("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatWhen(iso: string | null): string {
  if (!iso) {
    return "время не задано";
  }
  const date = new Date(iso);
  const diffMin = Math.round((date.getTime() - Date.now()) / 60000);
  if (diffMin >= 1 && diffMin < 24 * 60) {
    return `через ${diffMin} ${minuteWord(diffMin)}`;
  }
  return formatClock(iso) ?? "время не задано";
}

function formatDayTime(iso: string | null): string {
  if (!iso) {
    return "";
  }
  return new Date(iso).toLocaleString("ru-RU", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function isLive(meeting: Meeting): boolean {
  return LIVE_STATUS.includes(meeting.status);
}

function liveRank(status: MeetingStatus): number {
  if (status === "recording") {
    return 0;
  }
  if (status === "joining") {
    return 1;
  }
  return 2;
}

function byStartedAt(a: Meeting, b: Meeting): number {
  return (a.startedAt ?? "").localeCompare(b.startedAt ?? "");
}

function splitMeetings(meetings: Meeting[]): {
  hero: Meeting | null;
  upcoming: Meeting[];
  transcripts: Meeting[];
} {
  const live = meetings.filter(isLive).sort((a, b) => {
    const rank = liveRank(a.status) - liveRank(b.status);
    if (rank !== 0) {
      return rank;
    }
    return byStartedAt(a, b);
  });
  const hero = live[0] ?? null;
  const upcoming = hero ? live.slice(1) : [];
  const transcripts = meetings
    .filter((meeting) => !isLive(meeting))
    .sort((a, b) => byStartedAt(b, a));
  return { hero, upcoming, transcripts };
}

function subtitleText(count: number): string {
  if (count === 0) {
    return "Сегодня нет встреч, бот готов к записи";
  }
  return `Сегодня ${count} ${meetingWord(count)}, бот готов к записи следующих звонков`;
}

function botBusy(meetings: Meeting[]): boolean {
  return meetings.some(
    (meeting) => meeting.status === "joining" || meeting.status === "recording",
  );
}

export function HomeView({
  meetings,
  storage,
  url,
  error,
  notice,
  busy,
  onUrlChange,
  onSubmit,
  onSendBot,
}: HomeViewProps) {
  const { hero, upcoming, transcripts } = splitMeetings(meetings);
  const percent = storagePercent(storage.usedBytes);
  const busyBot = botBusy(meetings);

  return (
    <section className="home">
      <header className="home__header">
        <div>
          <h1 className="home__title">Главная</h1>
          <p className="home__subtitle">{subtitleText(storage.meetingCount)}</p>
        </div>
      </header>

      <div className="home__grid">
        <div className="home__main">
          {hero ? (
            <article className="home__hero">
              <div className="home__hero-body">
                <p className="home__hero-when">{formatWhen(hero.startedAt)}</p>
                <h2 className="home__hero-title">{meetingTitle(hero)}</h2>
                <p className="home__hero-meta">
                  {[formatClock(hero.startedAt), PLATFORM_LABEL[hero.platform]]
                    .filter(Boolean)
                    .join(" · ")}
                </p>
                <div className="home__hero-actions">
                  <button
                    className="home__btn home__btn--primary"
                    type="button"
                    disabled={busy}
                    onClick={() => onSendBot(hero.url)}
                  >
                    Отправить бота
                  </button>
                  <a
                    className="home__btn home__btn--ghost"
                    href={hero.url}
                    target="_blank"
                    rel="noreferrer"
                  >
                    Открыть звонок
                  </a>
                </div>
              </div>
              <aside className="home__bot" aria-label="Статус бота">
                <p className="home__bot-title">
                  {busyBot ? "Бот занят" : "Бот свободен"}
                </p>
                <p className="home__bot-text">
                  {busyBot
                    ? "Идёт запись, резюме появится после звонка."
                    : "Запись и резюме создаются автоматически."}
                </p>
              </aside>
            </article>
          ) : null}

          <section className="home__upcoming" aria-label="Ближайшие звонки">
            <div className="home__section-head">
              <h2 className="home__section-title">Ближайшие звонки</h2>
              <Link className="home__section-link" to="/calendar">
                весь календарь
              </Link>
            </div>
            {upcoming.length === 0 && !hero ? (
              <p className="home__empty-text">
                Пока нет ближайших звонков. Вставьте ссылку на встречу справа,
                чтобы отправить бота.
              </p>
            ) : upcoming.length === 0 ? (
              <p className="home__empty-text">
                Других ближайших звонков пока нет.
              </p>
            ) : (
              <ul className="home__rows">
                {upcoming.map((meeting) => (
                  <li key={meeting.id}>
                    <Link className="home__row" to={`/meetings/${meeting.id}`}>
                      <span className="home__row-time">
                        {formatClock(meeting.startedAt) ?? "нет времени"}
                      </span>
                      <span className="home__row-platform">
                        {PLATFORM_LABEL[meeting.platform]}
                      </span>
                      <span className="home__row-title">
                        {meetingTitle(meeting)}
                      </span>
                      <span
                        className={`home__pill home__pill--${meeting.status}`}
                      >
                        {STATUS_LABEL[meeting.status]}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>

        <aside className="home__aside">
          <form className="home__manual" onSubmit={onSubmit}>
            <h2 className="home__manual-title">Запустить запись вручную</h2>
            <p className="home__manual-text">
              Вставьте ссылку на Zoom, Google Meet или Яндекс Телемост, чтобы бот
              присоединился к встрече.
            </p>
            <div className="home__manual-row">
              <input
                className="home__input"
                value={url}
                onChange={(event) => onUrlChange(event.target.value)}
                placeholder="ссылка на встречу"
                aria-label="ссылка на встречу"
                autoComplete="off"
              />
              <button className="home__btn home__btn--primary" type="submit" disabled={busy}>
                Бот
              </button>
            </div>
            {error ? <p className="home__error">{error}</p> : null}
            {notice ? <p className="home__notice">{notice}</p> : null}
          </form>

          <section className="home__transcripts" aria-label="Последние расшифровки">
            <div className="home__section-head">
              <h2 className="home__section-title">Последние расшифровки</h2>
              <span className="home__section-meta">
                {transcripts.length} {fileWord(transcripts.length)}
              </span>
            </div>
            {transcripts.length === 0 ? (
              <p className="home__empty-text">Пока нет расшифровок.</p>
            ) : (
              <ul className="home__files">
                {transcripts.map((meeting) => (
                  <li key={meeting.id}>
                    <Link className="home__file" to={`/meetings/${meeting.id}`}>
                      <span className="home__file-mark" aria-hidden="true" />
                      <span className="home__file-body">
                        <span className="home__file-title">
                          {meetingTitle(meeting)}
                        </span>
                        <span className="home__file-meta">
                          {[
                            formatDayTime(meeting.startedAt),
                            STATUS_LABEL[meeting.status],
                          ]
                            .filter(Boolean)
                            .join(" · ")}
                        </span>
                      </span>
                      <span
                        className={`home__pill home__pill--${meeting.status}`}
                      >
                        {STATUS_LABEL[meeting.status]}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="home__storage" aria-label="Хранилище">
            <p className="home__storage-title">Хранилище: {percent}%</p>
            <p className="home__storage-text">
              {storage.meetingCount} {meetingWord(storage.meetingCount)} на этом
              компьютере, {formatBytes(storage.usedBytes)} аудио
            </p>
            <div className="home__storage-bar" aria-hidden="true">
              <span
                className="home__storage-fill"
                style={{ width: `${percent}%` }}
              />
            </div>
          </section>
        </aside>
      </div>
    </section>
  );
}
