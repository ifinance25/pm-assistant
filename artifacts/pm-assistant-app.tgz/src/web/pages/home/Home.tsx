import { FormEvent, useEffect, useState } from "react";
import type { Meeting } from "../../../shared/types.ts";
import { HomeView, type StorageStats } from "./HomeView.tsx";

type MeetingsResponse = {
  meetings: Meeting[];
  storage: StorageStats;
};

type CreateMeetingResponse = {
  meeting?: Meeting;
  alreadyRunning?: boolean;
  error?: string;
};

export function Home() {
  const [url, setUrl] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [storage, setStorage] = useState<StorageStats>({
    meetingCount: 0,
    usedBytes: 0,
  });

  async function loadMeetings(): Promise<void> {
    const res = await fetch("/api/meetings");
    if (!res.ok) {
      throw new Error("не удалось загрузить встречи");
    }
    const body = (await res.json()) as MeetingsResponse;
    setMeetings(body.meetings);
    setStorage(body.storage);
  }

  useEffect(() => {
    void loadMeetings().catch(() => {
      setError("Не удалось загрузить список встреч");
    });
    const timer = window.setInterval(() => {
      void loadMeetings().catch(() => undefined);
    }, 2000);
    return () => window.clearInterval(timer);
  }, []);

  async function postMeeting(targetUrl: string): Promise<void> {
    setNotice(null);
    setBusy(true);
    const submitted = targetUrl;
    try {
      const res = await fetch("/api/meetings", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ url: targetUrl }),
      });
      const body = (await res.json()) as CreateMeetingResponse;
      if (!res.ok) {
        setError(body.error ?? "Не удалось отправить бота");
        setUrl(submitted);
        return;
      }
      setError(null);
      setUrl(submitted);
      if (body.alreadyRunning) {
        setNotice("Уже запущено");
      } else {
        setNotice(null);
      }
      await loadMeetings();
    } catch {
      setError("Не удалось отправить бота");
      setUrl(submitted);
    } finally {
      setBusy(false);
    }
  }

  async function onSubmit(event: FormEvent<HTMLFormElement>): Promise<void> {
    event.preventDefault();
    await postMeeting(url);
  }

  return (
    <HomeView
      meetings={meetings}
      storage={storage}
      url={url}
      error={error}
      notice={notice}
      busy={busy}
      onUrlChange={setUrl}
      onSubmit={onSubmit}
      onSendBot={(meetingUrl) => {
        void postMeeting(meetingUrl);
      }}
    />
  );
}
