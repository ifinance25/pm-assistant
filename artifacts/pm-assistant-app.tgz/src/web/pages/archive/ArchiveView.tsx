import { Link } from "react-router-dom";
import "./archive.css";

export type ArchiveHit = {
  id: string;
  title: string | null;
  platform: string;
  status: string;
  startedAt: string | null;
  snippet: string;
  href: string;
  matchCount: number;
  decisionCount: number;
  taskCount: number;
};

export type ArchiveFilters = {
  platform: string;
  period: string;
  status: string;
};

export type ArchiveContext = {
  id: string;
  title: string;
  platform: string;
  startedAt: string | null;
  durationLabel: string | null;
  snippet: string;
  href: string;
  decisionCount: number;
  taskCount: number;
  riskCount: number;
};

export type ArchiveViewProps = {
  query: string;
  filters: ArchiveFilters;
  results: ArchiveHit[];
  selectedId: string | null;
  selected: ArchiveContext | null;
  loading?: boolean;
  onToggleFilter?: (group: keyof ArchiveFilters, id: string) => void;
  onSelect?: (id: string) => void;
};

export type SearchHit = {
  id: string;
  title: string | null;
  platform: string;
  status: string;
  startedAt: string | null;
  snippet: string;
  href: string;
  matchCount?: number;
  decisionCount?: number;
  taskCount?: number;
};

export function hitsFromSearch(query: string, apiHits: SearchHit[]): ArchiveHit[] {
  if (!query.trim()) {
    return [];
  }
  return apiHits.map((hit) => ({
    id: hit.id,
    title: hit.title,
    platform: hit.platform,
    status: hit.status,
    startedAt: hit.startedAt,
    snippet: hit.snippet,
    href: hit.href,
    matchCount: hit.matchCount ?? (hit.snippet ? 1 : 0),
    decisionCount: hit.decisionCount ?? 0,
    taskCount: hit.taskCount ?? 0,
  }));
}

const PLATFORMS = [
  { id: "zoom", label: "Zoom" },
  { id: "meet", label: "Google Meet" },
  { id: "telemost", label: "Яндекс.Телемост" },
] as const;

const PERIODS = [
  { id: "7d", label: "7 дней" },
  { id: "month", label: "Этот месяц" },
  { id: "quarter", label: "Квартал" },
] as const;

const STATUSES = [
  { id: "ready", label: "Готово" },
  { id: "error", label: "Ошибка" },
  { id: "processing", label: "В обработке" },
] as const;

const PLATFORM_LABEL: Record<string, string> = {
  zoom: "Zoom",
  meet: "Google Meet",
  telemost: "Яндекс.Телемост",
  unknown: "Другое",
};

function chipClass(active: boolean): string {
  return active ? "archive__chip archive__chip--active" : "archive__chip";
}

function plural(count: number, one: string, few: string, many: string): string {
  const mod10 = count % 10;
  const mod100 = count % 100;
  if (mod10 === 1 && mod100 !== 11) {
    return `${count} ${one}`;
  }
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) {
    return `${count} ${few}`;
  }
  return `${count} ${many}`;
}

function formatWhen(iso: string | null): string {
  if (!iso) {
    return "";
  }
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) {
    return "";
  }
  return date.toLocaleString("ru-RU", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function Highlight({ text, query }: { text: string; query: string }) {
  const needle = query.trim().split(/\s+/)[0] ?? "";
  if (!needle) {
    return text;
  }
  const idx = text.toLowerCase().indexOf(needle.toLowerCase());
  if (idx < 0) {
    return text;
  }
  return (
    <>
      {text.slice(0, idx)}
      <mark>{text.slice(idx, idx + needle.length)}</mark>
      {text.slice(idx + needle.length)}
    </>
  );
}

export function ArchiveView(props: ArchiveViewProps) {
  const { filters, onToggleFilter } = props;

  return (
    <section className="archive">
      <header className="archive__top">
        <h1 className="archive__title">Расшифровки</h1>
        <p className="archive__lead">
          Поиск по транскриптам, резюме и задачам
        </p>
      </header>

      <div className="archive__body">
        <aside className="archive__filters" aria-label="Фильтры">
          <h2 className="archive__filters-title">Фильтры</h2>

          <div className="archive__group">
            <h3 className="archive__group-title">Источник</h3>
            <ul className="archive__list">
              {PLATFORMS.map((item) => (
                <li key={item.id}>
                  <button
                    type="button"
                    className={chipClass(filters.platform === item.id)}
                    onClick={() => onToggleFilter?.("platform", item.id)}
                  >
                    <span className={`archive__dot archive__dot--${item.id}`} />
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="archive__group">
            <h3 className="archive__group-title">Период</h3>
            <ul className="archive__list">
              {PERIODS.map((item) => (
                <li key={item.id}>
                  <button
                    type="button"
                    className={chipClass(filters.period === item.id)}
                    onClick={() => onToggleFilter?.("period", item.id)}
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="archive__group">
            <h3 className="archive__group-title">Статус</h3>
            <ul className="archive__list">
              {STATUSES.map((item) => (
                <li key={item.id}>
                  <button
                    type="button"
                    className={chipClass(filters.status === item.id)}
                    onClick={() => onToggleFilter?.("status", item.id)}
                  >
                    <span
                      className={`archive__status archive__status--${item.id}`}
                    />
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        <div className="archive__feed">
          <div className="archive__feed-head">
            <p className="archive__count">
              {props.loading
                ? "Ищем…"
                : props.results.length === 0
                  ? "Ничего не найдено"
                  : `Найдено ${plural(props.results.length, "встреча", "встречи", "встреч")}`}
            </p>
          </div>

          {props.results.length === 0 && !props.loading ? (
            <p className="archive__empty">
              Ничего не найдено. Измените запрос или сбросьте фильтры.
            </p>
          ) : (
            <ul className="archive__hits">
              {props.results.map((hit) => (
                <li key={hit.id}>
                  <button
                    type="button"
                    className={
                      props.selectedId === hit.id
                        ? "archive__card archive__card--active"
                        : "archive__card"
                    }
                    onClick={() => props.onSelect?.(hit.id)}
                  >
                    <div className="archive__card-meta">
                      <span className={`archive__dot archive__dot--${hit.platform}`} />
                      <span>{PLATFORM_LABEL[hit.platform] ?? hit.platform}</span>
                      {formatWhen(hit.startedAt) ? (
                        <time dateTime={hit.startedAt ?? undefined}>
                          {formatWhen(hit.startedAt)}
                        </time>
                      ) : null}
                    </div>
                    <h3 className="archive__card-title">
                      {hit.title ?? "Встреча без названия"}
                    </h3>
                    <p className="archive__snippet">
                      <Highlight text={hit.snippet} query={props.query} />
                    </p>
                    <p className="archive__card-counts">
                      {plural(hit.matchCount, "совпадение", "совпадения", "совпадений")}
                      {" · "}
                      {plural(hit.decisionCount, "решение", "решения", "решений")}
                      {" · "}
                      {plural(hit.taskCount, "задача", "задачи", "задач")}
                    </p>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <aside className="archive__context" aria-label="Контекст встречи">
          {props.selected ? (
            <>
              <h2 className="archive__context-title">{props.selected.title}</h2>
              <p className="archive__context-meta">
                {PLATFORM_LABEL[props.selected.platform] ?? props.selected.platform}
                {formatWhen(props.selected.startedAt)
                  ? ` · ${formatWhen(props.selected.startedAt)}`
                  : ""}
                {props.selected.durationLabel
                  ? ` · ${props.selected.durationLabel}`
                  : ""}
              </p>
              <div className="archive__quote">
                <p className="archive__quote-label">Лучшее совпадение</p>
                <p className="archive__quote-text">{props.selected.snippet}</p>
              </div>
              <ul className="archive__stats">
                <li>{plural(props.selected.decisionCount, "решение", "решения", "решений")}</li>
                <li>{plural(props.selected.taskCount, "задача", "задачи", "задач")}</li>
                <li>{plural(props.selected.riskCount, "риск", "риска", "рисков")}</li>
              </ul>
              <Link className="archive__open" to={props.selected.href}>
                Открыть встречу
              </Link>
            </>
          ) : (
            <p className="archive__context-empty">
              Выберите встречу в списке, чтобы увидеть контекст.
            </p>
          )}
        </aside>
      </div>
    </section>
  );
}
