import { useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import type { MeetingDetail } from "../../../shared/types.ts";
import {
  ArchiveView,
  hitsFromSearch,
  type ArchiveContext,
  type ArchiveFilters,
  type ArchiveHit,
  type SearchHit,
} from "./ArchiveView.tsx";

const PROCESSING = new Set([
  "queued",
  "joining",
  "recording",
  "transcribing",
  "summarizing",
]);

function countLines(text: string | undefined): number {
  if (!text) {
    return 0;
  }
  return text
    .split(/\n+/)
    .map((line) => line.replace(/^[-•]\s*/, "").trim())
    .filter(Boolean).length;
}

function durationLabel(detail: MeetingDetail): string | null {
  const start = detail.meeting.startedAt
    ? Date.parse(detail.meeting.startedAt)
    : Number.NaN;
  const end = detail.meeting.endedAt
    ? Date.parse(detail.meeting.endedAt)
    : Number.NaN;
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) {
    return null;
  }
  return `${Math.round((end - start) / 60_000)} мин`;
}

function matchCount(detail: MeetingDetail, query: string): number {
  const needle = query.trim().split(/\s+/)[0]?.toLowerCase() ?? "";
  if (!needle) {
    return 0;
  }
  const blobs = [
    ...detail.transcript.map((segment) => segment.text),
    detail.summary?.headline ?? "",
    detail.summary?.decisions ?? "",
    detail.summary?.risks ?? "",
    detail.summary?.nextStep ?? "",
    ...detail.actionItems.map((item) => item.title),
    detail.meeting.title ?? "",
  ];
  const hits = blobs.filter((text) => text.toLowerCase().includes(needle)).length;
  return Math.max(hits, 1);
}

function contextFrom(
  hit: ArchiveHit,
  detail: MeetingDetail | null,
): ArchiveContext {
  return {
    id: hit.id,
    title: hit.title ?? "Встреча без названия",
    platform: hit.platform,
    startedAt: hit.startedAt,
    durationLabel: detail ? durationLabel(detail) : null,
    snippet: hit.snippet,
    href: hit.href,
    decisionCount: detail
      ? countLines(detail.summary?.decisions)
      : hit.decisionCount,
    taskCount: detail ? detail.actionItems.length : hit.taskCount,
    riskCount: detail ? countLines(detail.summary?.risks) : 0,
  };
}

async function loadDetail(id: string): Promise<MeetingDetail | null> {
  const res = await fetch(`/api/meetings/${id}`);
  if (!res.ok) {
    return null;
  }
  return (await res.json()) as MeetingDetail;
}

export function ArchivePage() {
  const [params] = useSearchParams();
  const query = params.get("q") ?? "";
  const [filters, setFilters] = useState<ArchiveFilters>({
    platform: "",
    period: "",
    status: "",
  });
  const [results, setResults] = useState<ArchiveHit[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selected, setSelected] = useState<ArchiveContext | null>(null);
  const [loading, setLoading] = useState(false);
  const selectedIdRef = useRef<string | null>(null);

  useEffect(() => {
    const ac = new AbortController();
    const q = query.trim();
    if (!q) {
      setResults([]);
      selectedIdRef.current = null;
      setSelectedId(null);
      setSelected(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    const search = new URLSearchParams();
    search.set("q", q);
    if (filters.platform) {
      search.set("platform", filters.platform);
    }
    if (filters.period) {
      search.set("period", filters.period);
    }
    if (filters.status === "ready" || filters.status === "error") {
      search.set("status", filters.status);
    }
    fetch(`/api/search?${search.toString()}`, { signal: ac.signal })
      .then(async (res) => {
        if (!res.ok) {
          return [];
        }
        const body = (await res.json()) as { results?: SearchHit[] };
        let hits = Array.isArray(body.results) ? body.results : [];
        if (filters.status === "processing") {
          hits = hits.filter((hit) => PROCESSING.has(hit.status));
        }
        return hitsFromSearch(q, hits);
      })
      .then(async (hits) => {
        if (ac.signal.aborted) {
          return;
        }
        const details = await Promise.all(
          hits.map((hit) => loadDetail(hit.id)),
        );
        if (ac.signal.aborted) {
          return;
        }
        const enriched = hits.map((hit, index) => {
          const detail = details[index];
          if (!detail) {
            return hit;
          }
          return {
            ...hit,
            matchCount: matchCount(detail, q),
            decisionCount: countLines(detail.summary?.decisions),
            taskCount: detail.actionItems.length,
          };
        });
        setResults(enriched);
        const keepId = selectedIdRef.current;
        const nextId =
          keepId && enriched.some((hit) => hit.id === keepId)
            ? keepId
            : (enriched[0]?.id ?? null);
        selectedIdRef.current = nextId;
        setSelectedId(nextId);
        const nextHit = enriched.find((hit) => hit.id === nextId) ?? null;
        const nextDetail = nextHit
          ? details[enriched.findIndex((hit) => hit.id === nextHit.id)]
          : null;
        setSelected(nextHit ? contextFrom(nextHit, nextDetail ?? null) : null);
      })
      .catch((err: unknown) => {
        if (err instanceof DOMException && err.name === "AbortError") {
          return;
        }
        setResults([]);
        setSelectedId(null);
        setSelected(null);
      })
      .finally(() => {
        if (!ac.signal.aborted) {
          setLoading(false);
        }
      });
    return () => ac.abort();
  }, [query, filters.platform, filters.period, filters.status]);

  function onToggleFilter(group: keyof ArchiveFilters, id: string) {
    setFilters((current) => ({
      ...current,
      [group]: current[group] === id ? "" : id,
    }));
  }

  function onSelect(id: string) {
    const hit = results.find((item) => item.id === id);
    if (!hit) {
      return;
    }
    selectedIdRef.current = id;
    setSelectedId(id);
    setSelected(contextFrom(hit, null));
    void loadDetail(id).then((detail) => {
      setSelected(contextFrom(hit, detail));
      if (detail) {
        setResults((current) =>
          current.map((item) =>
            item.id === id
              ? {
                  ...item,
                  matchCount: matchCount(detail, query),
                  decisionCount: countLines(detail.summary?.decisions),
                  taskCount: detail.actionItems.length,
                }
              : item,
          ),
        );
      }
    });
  }

  return (
    <ArchiveView
      query={query}
      filters={filters}
      results={results}
      selectedId={selectedId}
      selected={selected}
      loading={loading}
      onToggleFilter={onToggleFilter}
      onSelect={onSelect}
    />
  );
}
