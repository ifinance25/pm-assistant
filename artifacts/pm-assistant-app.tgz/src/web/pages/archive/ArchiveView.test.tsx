import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { renderToString } from "react-dom/server";
import { MemoryRouter } from "react-router-dom";
import { describe, expect, it } from "vitest";
import {
  ArchiveView,
  hitsFromSearch,
  type ArchiveContext,
  type ArchiveHit,
  type ArchiveViewProps,
} from "./ArchiveView.tsx";

const emptyFilters = { platform: "", period: "", status: "" };

function renderView(overrides: Partial<ArchiveViewProps> = {}) {
  return renderToString(
    <MemoryRouter>
      <ArchiveView
        query=""
        filters={emptyFilters}
        results={[]}
        selectedId={null}
        selected={null}
        {...overrides}
      />
    </MemoryRouter>,
  );
}

describe("ArchiveView", () => {
  it("показывает заголовок Расшифровки и подпись про поиск по транскриптам", () => {
    const html = renderView();
    expect(html).toContain("Расшифровки");
    expect(html).toContain("Поиск по транскриптам, резюме и задачам");
  });

  it("показывает фильтры источник, период и статус, активный с терракотовым акцентом", () => {
    const html = renderView({
      filters: { platform: "zoom", period: "month", status: "ready" },
    });
    expect(html).toContain("Фильтры");
    expect(html).toContain("Источник");
    expect(html).toContain("Zoom");
    expect(html).toContain("Google Meet");
    expect(html).toContain("Яндекс.Телемост");
    expect(html).toContain("Период");
    expect(html).toContain("7 дней");
    expect(html).toContain("Этот месяц");
    expect(html).toContain("Квартал");
    expect(html).toContain("Статус");
    expect(html).toContain("Готово");
    expect(html).toContain("Ошибка");
    expect(html).toContain("В обработке");
    expect(html).toContain("archive__chip--active");
  });

  it("показывает карточки результатов со сниппетом и счётчиками", () => {
    const hit: ArchiveHit = {
      id: "m1",
      title: "Стендап команды",
      platform: "zoom",
      status: "ready",
      startedAt: "2026-09-04T07:00:00.000Z",
      snippet: "договорились взять MVP: бот по ссылке",
      href: "/meetings/m1",
      matchCount: 3,
      decisionCount: 2,
      taskCount: 4,
    };
    const html = renderView({ results: [hit], selectedId: "m1" });
    expect(html).toContain("Стендап команды");
    expect(html).toContain("договорились взять MVP: бот по ссылке");
    expect(html).toContain("3 совпадения");
    expect(html).toContain("2 решения");
    expect(html).toContain("4 задачи");
  });

  it("в правой колонке показывает выбранную встречу и ссылку Открыть встречу", () => {
    const selected: ArchiveContext = {
      id: "m1",
      title: "Стендап команды",
      platform: "zoom",
      startedAt: "2026-09-04T07:00:00.000Z",
      durationLabel: "53 мин",
      snippet: "календарь локальный",
      href: "/meetings/m1",
      decisionCount: 3,
      taskCount: 4,
      riskCount: 2,
    };
    const html = renderView({ selectedId: "m1", selected });
    expect(html).toContain("Стендап команды");
    expect(html).toContain("Открыть встречу");
    expect(html).toContain('href="/meetings/m1"');
    expect(html).toContain("календарь локальный");
  });

  it("пустой поиск не подставляет чужие встречи", () => {
    const planted: ArchiveHit = {
      id: "alien",
      title: "Планирование roadmap Q3",
      platform: "zoom",
      status: "ready",
      startedAt: "2026-09-04T07:00:00.000Z",
      snippet: "чужой фрагмент",
      href: "/meetings/alien",
      matchCount: 1,
      decisionCount: 0,
      taskCount: 0,
    };
    expect(hitsFromSearch("", [planted])).toEqual([]);
    const html = renderView({ query: "", results: hitsFromSearch("", [planted]) });
    expect(html).toContain("Ничего не найдено");
    expect(html).not.toContain("Планирование roadmap Q3");
    expect(html).not.toContain("чужой фрагмент");
  });

  it("верстка на токенах T14 без старого синего", () => {
    const css = readFileSync(
      join(dirname(fileURLToPath(import.meta.url)), "archive.css"),
      "utf8",
    );
    expect(css).not.toMatch(/#0062[Ff]{2}/);
    expect(css).toContain("var(--accent)");
    expect(css).toContain("var(--radius-card)");
    expect(css).toContain("archive__context");
    expect(css).toContain("archive__chip--active");
  });
});
