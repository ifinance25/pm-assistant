import { Link } from "react-router-dom";
import type { Meeting, Platform } from "../../../shared/types.ts";
import "./calendar.css";

const PLATFORM_LABEL: Record<Platform, string> = {
  zoom: "Zoom",
  meet: "Google Meet",
  telemost: "Яндекс Телемост",
  unknown: "Платформа",
};

export type CalendarViewProps = {
  meetings: Meeting[];
};

function formatRowWhen(iso: string | null): string {
  if (!iso) {
    return "время не задано";
  }
  const date = new Date(iso);
  const now = new Date();
  const sameDay =
    date.getFullYear() === now.getFullYear() &&
    date.getMonth() === now.getMonth() &&
    date.getDate() === now.getDate();
  const time = date.toLocaleTimeString("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
  });
  if (sameDay) {
    return `сегодня ${time}`;
  }
  return date.toLocaleString("ru-RU", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function CalendarList({
  meetings,
  compact = false,
}: {
  meetings: Meeting[];
  compact?: boolean;
}) {
  if (meetings.length === 0) {
    return null;
  }

  return (
    <ul
      className={
        compact ? "calendar__list calendar__list--compact" : "calendar__list"
      }
    >
      {meetings.map((meeting) => (
        <li key={meeting.id} className="calendar__item">
          <div className="calendar__item-body">
            <span className="calendar__item-title">
              {meeting.title ?? meeting.url}
            </span>
            <span className="calendar__item-meta">
              <time dateTime={meeting.startedAt ?? undefined}>
                {formatRowWhen(meeting.startedAt)}
              </time>
              {" · "}
              {PLATFORM_LABEL[meeting.platform]}
            </span>
            <span className="calendar__item-url">{meeting.url}</span>
          </div>
          <Link className="calendar__open" to={`/meetings/${meeting.id}`}>
            Открыть
          </Link>
        </li>
      ))}
    </ul>
  );
}

export function CalendarView({ meetings }: CalendarViewProps) {
  return (
    <section className="calendar">
      <header className="calendar__header">
        <h1 className="calendar__title">Календарь</h1>
        <p className="calendar__lead">Сохранённые встречи и ссылки из базы</p>
      </header>
      <aside className="calendar__banner">
        <p className="calendar__banner-title">Это локальный календарь</p>
        <p className="calendar__banner-text">
          Google и Apple не подключены. Здесь встречи, которые уже есть в базе,
          и их ссылки. Бот запускается с Главной по URL.
        </p>
      </aside>
      {meetings.length === 0 ? (
        <p className="calendar__empty">
          Пока нет сохранённых встреч.{" "}
          <Link to="/">Вставьте ссылку на встречу на Главной</Link>.
        </p>
      ) : (
        <CalendarList meetings={meetings} />
      )}
    </section>
  );
}
