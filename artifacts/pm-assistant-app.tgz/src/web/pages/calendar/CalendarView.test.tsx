import { renderToString } from "react-dom/server";
import { MemoryRouter } from "react-router-dom";
import { describe, expect, it } from "vitest";
import type { Meeting } from "../../../shared/types.ts";
import { CalendarView } from "./CalendarView.tsx";

const meeting: Meeting = {
  id: "m-cal-1",
  url: "https://zoom.us/j/555111222",
  platform: "zoom",
  title: "Стендап",
  status: "queued",
  recordingMode: "text",
  startedAt: "2026-09-04T08:00:00.000Z",
  endedAt: null,
  error: null,
  announcementStatus: null,
  source: "stub",
  audioPath: null,
};

describe("CalendarView", () => {
  it("пустое состояние приглашает вставить ссылку на Главной", () => {
    const html = renderToString(
      <MemoryRouter>
        <CalendarView meetings={[]} />
      </MemoryRouter>,
    );
    expect(html).toContain("Календарь");
    expect(html).toContain("Сохранённые встречи и ссылки из базы");
    expect(html).toContain("Это локальный календарь");
    expect(html).toContain("Google и Apple не подключены");
    expect(html).toContain("Вставьте ссылку на встречу на Главной");
    expect(html).toContain('href="/"');
    expect(html).not.toContain("будет позже");
    expect(html).not.toContain("не подключено в этой версии");
    expect(html).not.toContain("\u2014");
  });

  it("показывает строку: название, время, платформа, URL и кнопку Открыть", () => {
    const html = renderToString(
      <MemoryRouter>
        <CalendarView meetings={[meeting]} />
      </MemoryRouter>,
    );
    expect(html).toContain("Стендап");
    expect(html).toContain("Zoom");
    expect(html).toContain("https://zoom.us/j/555111222");
    expect(html).toContain("Открыть");
    expect(html).toContain('href="/meetings/m-cal-1"');
    expect(html).toMatch(/\d{2}:\d{2}/);
    expect(html).not.toContain("будет позже");
    expect(html).not.toContain("не подключено в этой версии");
    expect(html).not.toContain("\u2014");
    expect(html).not.toContain("#0062FF");
  });
});
