import { useCallback, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import type { MeetingDetail, Settings } from "../../../shared/types.ts";
import { MeetingView } from "./MeetingView.tsx";
import "./meeting.css";

export function MeetingPage() {
  const { id } = useParams();
  const [detail, setDetail] = useState<MeetingDetail | null>(null);
  const [asanaProjectLabel, setAsanaProjectLabel] = useState("");
  const [asanaNotice, setAsanaNotice] = useState<string | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  const load = useCallback(async (meetingId: string) => {
    const res = await fetch(`/api/meetings/${meetingId}`);
    if (res.status === 404) {
      setDetail(null);
      setLoadError("Встреча не найдена");
      return;
    }
    if (!res.ok) {
      setLoadError("Не удалось загрузить встречу");
      return;
    }
    setLoadError(null);
    setDetail((await res.json()) as MeetingDetail);
  }, []);

  useEffect(() => {
    if (!id) {
      setLoadError("Встреча не найдена");
      return;
    }
    void load(id);
  }, [id, load]);

  useEffect(() => {
    if (!id || !detail) {
      return;
    }
    const status = detail.meeting.status;
    if (status === "ready" || status === "error") {
      return;
    }
    const timer = window.setInterval(() => {
      void load(id);
    }, 1000);
    return () => window.clearInterval(timer);
  }, [id, detail, load]);

  useEffect(() => {
    void fetch("/api/settings")
      .then((res) => (res.ok ? res.json() : null))
      .then((settings: Settings | null) => {
        if (settings) {
          setAsanaProjectLabel(settings.asanaProjectLabel);
        }
      });
  }, []);

  const onAsanaQueue = async () => {
    if (!id) {
      return;
    }
    const res = await fetch(`/api/meetings/${id}/asana-queue`, {
      method: "POST",
    });
    if (!res.ok) {
      return;
    }
    const body = (await res.json()) as Pick<MeetingDetail, "actionItems"> & {
      asana?: { notice?: string };
    };
    setDetail((prev) =>
      prev ? { ...prev, actionItems: body.actionItems } : prev,
    );
    setAsanaNotice(body.asana?.notice ?? null);
  };

  const onRetry = async () => {
    if (!id || !detail) {
      return;
    }
    const path = detail.meeting.audioPath
      ? `/api/meetings/${id}/transcribe`
      : `/api/meetings/${id}/retry`;
    const res = await fetch(path, { method: "POST" });
    if (res.ok) {
      await load(id);
    }
  };

  if (loadError && !detail) {
    return (
      <section className="meeting">
        <h1 className="meeting__title">{loadError}</h1>
      </section>
    );
  }

  if (!detail) {
    return (
      <section className="meeting">
        <p className="meeting__muted">Загрузка итогов встречи...</p>
      </section>
    );
  }

  return (
    <MeetingView
      detail={detail}
      asanaProjectLabel={asanaProjectLabel}
      asanaNotice={asanaNotice}
      onAsanaQueue={() => void onAsanaQueue()}
      onRetry={() => void onRetry()}
    />
  );
}
