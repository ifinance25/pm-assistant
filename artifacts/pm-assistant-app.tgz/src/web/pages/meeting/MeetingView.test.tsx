import { renderToString } from "react-dom/server";
import { describe, expect, it } from "vitest";
import type { Meeting } from "../../../shared/types.ts";
import { MeetingView } from "./MeetingView.tsx";

const meeting: Meeting = {
  id: "m1",
  url: "https://zoom.us/j/1",
  platform: "zoom",
  title: "Пилот",
  status: "ready",
  recordingMode: "text",
  startedAt: "2026-09-03T10:00:00.000Z",
  endedAt: "2026-09-03T10:47:00.000Z",
  error: null,
  announcementStatus: null,
  source: "stub",
  audioPath: null,
};

describe("MeetingView", () => {
  it("не падает на пустом транскрипте", () => {
    const html = renderToString(
      <MeetingView
        detail={{
          meeting,
          transcript: [],
          summary: null,
          actionItems: [],
        }}
        asanaProjectLabel=""
      />,
    );
    expect(html.length).toBeGreaterThan(0);
    expect(html).toContain("Транскрипт");
    expect(html).toContain("Слайды");
    expect(html).toContain("захват недоступен");
  });

  it("ставит заголовок Итоги встречи, подпись с названием и бейдж", () => {
    const html = renderToString(
      <MeetingView
        detail={{
          meeting,
          transcript: [],
          summary: null,
          actionItems: [],
        }}
        asanaProjectLabel=""
      />,
    );
    expect(html).toMatch(/<h1[^>]*>Итоги встречи<\/h1>/);
    expect(html).toContain("Пилот");
    expect(html).toContain("47 мин");
    expect(html).toContain("Готово");
    expect(html).not.toContain("Готово к отправке");
  });

  it("рисует три колонки: поиск, резюме и задачи с кнопкой Asana", () => {
    const html = renderToString(
      <MeetingView
        detail={{
          meeting,
          transcript: [
            {
              id: "s1",
              meetingId: "m1",
              speaker: "Анна",
              startedAtMs: 0,
              endedAtMs: 4000,
              text: "Берём прототип к четвергу",
            },
          ],
          summary: {
            meetingId: "m1",
            headline: "Согласовали MVP",
            decisions: "UI как в макете\nотправка в Asana",
            risks: "STT без ключа",
            nextStep: "Собрать прототип",
          },
          actionItems: [
            {
              id: "a1",
              meetingId: "m1",
              assignee: "Илья",
              title: "Поле ссылки на Главной",
              dueAt: "2026-09-04",
              timecodeMs: 0,
              segmentId: "s1",
              asanaState: "none",
            },
          ],
        }}
        asanaProjectLabel="Протоколы"
      />,
    );
    expect(html).toContain("Поиск по словам и спикерам");
    expect(html).toContain("Краткое резюме");
    expect(html).toContain("Основной результат");
    expect(html).toContain("Решения");
    expect(html).toContain("Риски");
    expect(html).toContain("Следующий шаг");
    expect(html).toContain("фрагментов");
    expect(html).toContain("Задачи из встречи");
    expect(html).toContain("Отправить 1 задачу в Asana");
    expect(html).toContain('href="#segment-s1"');
  });

  it("в transcribing показывает сегмент и заглушку realtime", () => {
    const html = renderToString(
      <MeetingView
        detail={{
          meeting: { ...meeting, status: "transcribing", source: "stub" },
          transcript: [
            {
              id: "s1",
              meetingId: "m1",
              speaker: "Анна Петрова",
              startedAtMs: 0,
              endedAtMs: 4000,
              text: "Начинаем standup по пилоту",
            },
          ],
          summary: null,
          actionItems: [],
          realtime: { mode: "stub", caption: "заглушка realtime" },
        }}
        asanaProjectLabel=""
      />,
    );
    expect(html).toContain("Начинаем standup по пилоту");
    expect(html).toContain("заглушка realtime");
    expect(html).not.toContain(
      "Транскрипт и задачи появятся, когда обработка закончится",
    );
  });

  it("в recording с live показывает подпись живой", () => {
    const html = renderToString(
      <MeetingView
        detail={{
          meeting: { ...meeting, status: "recording", source: "live" },
          transcript: [
            {
              id: "s1",
              meetingId: "m1",
              speaker: "Спикер 1",
              startedAtMs: 1000,
              endedAtMs: 3000,
              text: "Черновик реплики",
            },
          ],
          summary: null,
          actionItems: [],
          realtime: { mode: "live", caption: "живой" },
        }}
        asanaProjectLabel=""
      />,
    );
    expect(html).toContain("Черновик реплики");
    expect(html).toContain("живой");
  });

  it("без ключа показывает к отправке и не содержит секретов", () => {
    const html = renderToString(
      <MeetingView
        detail={{
          meeting,
          transcript: [],
          summary: null,
          actionItems: [
            {
              id: "a1",
              meetingId: "m1",
              assignee: "Илья",
              title: "Проверить протокол",
              dueAt: "2026-09-04",
              timecodeMs: null,
              segmentId: null,
              asanaState: "queued_for_asana",
            },
          ],
        }}
        asanaProjectLabel=""
        asanaNotice="Нет ключа ASANA_PAT. Задачи помечены к отправке."
      />,
    );
    expect(html).toContain("к отправке");
    expect(html).toContain("Нет ключа ASANA_PAT");
    expect(html).not.toContain("Bearer");
    expect(html).not.toMatch(/[0-9]\/[0-9]{10,}/);
    expect(html).not.toContain("test-pat");
  });

  it("всегда показывает блок слайдов и подпись захват недоступен", () => {
    const html = renderToString(
      <MeetingView
        detail={{
          meeting,
          transcript: [],
          summary: null,
          actionItems: [],
        }}
        asanaProjectLabel=""
        slides={{
          mode: "stub",
          captureAvailable: false,
          notice: "захват недоступен",
          slots: [
            {
              id: "slot-1",
              title: "Повестка standup",
              capturedAtMs: 0,
            },
          ],
        }}
      />,
    );
    expect(html).toContain("Слайды");
    expect(html).toContain("захват недоступен");
    expect(html).toContain("Повестка standup");
  });

  it("показывает voiceprintLabel у сегмента", () => {
    const html = renderToString(
      <MeetingView
        detail={{
          meeting,
          transcript: [
            {
              id: "s1",
              meetingId: "m1",
              speaker: "Спикер 1",
              startedAtMs: 0,
              endedAtMs: 4000,
              text: "Начинаем standup по пилоту",
              voiceprintLabel: "отпечаток не рассчитан",
            },
          ],
          summary: null,
          actionItems: [],
        }}
        asanaProjectLabel=""
      />,
    );
    expect(html).toContain("Спикер 1");
    expect(html).toContain("отпечаток не рассчитан");
  });

  it("при ошибке и audio_path показывает Повторить транскрибацию", () => {
    const html = renderToString(
      <MeetingView
        detail={{
          meeting: {
            ...meeting,
            status: "error",
            error: "llm ответил статусом 429",
            audioPath: "/tmp/a.wav",
          },
          transcript: [],
          summary: null,
          actionItems: [],
        }}
        asanaProjectLabel=""
        onRetry={() => undefined}
      />,
    );
    expect(html).toContain("Повторить транскрибацию");
    expect(html).not.toContain(">Повторить<");
  });
});
