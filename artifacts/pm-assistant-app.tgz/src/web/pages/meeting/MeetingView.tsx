import { useMemo, useState } from "react";
import demoMeeting from "../../../../fixtures/demo-meeting.json";
import {
  unavailableSlides,
  type SlideSlot,
  type SlidesCapture,
} from "../../../adapters/slides/types.ts";
import { VOICEPRINT_UNAVAILABLE } from "../../../adapters/voiceprint/index.ts";
import {
  type ActionItem,
  type Meeting,
  type MeetingDetail,
  type MeetingStatus,
  type TranscriptSegment,
  realtimeCaption,
} from "../../../shared/types.ts";

const STATUS_LABEL: Record<MeetingStatus, string> = {
  queued: "В очереди",
  joining: "Подключение",
  recording: "Идёт запись",
  transcribing: "Расшифровка",
  summarizing: "Готовим резюме",
  ready: "Готово",
  error: "Ошибка",
};

export type MeetingViewProps = {
  detail: MeetingDetail;
  asanaProjectLabel: string;
  asanaNotice?: string | null;
  onAsanaQueue?: () => void;
  onRetry?: () => void;
  slides?: SlidesCapture;
};

export function formatTimecode(ms: number): string {
  const totalSec = Math.max(0, Math.floor(ms / 1000));
  const minutes = Math.floor(totalSec / 60);
  const seconds = totalSec % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

const MONTHS_SHORT = [
  "янв",
  "фев",
  "мар",
  "апр",
  "май",
  "июн",
  "июл",
  "авг",
  "сен",
  "окт",
  "ноя",
  "дек",
];

function formatDate(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) {
    return iso;
  }
  return `${d.getDate()} ${MONTHS_SHORT[d.getMonth()]}`;
}

function formatDue(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) {
    return iso;
  }
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  return `до ${dd}.${mm}`;
}

function durationLabel(meeting: Meeting): string | null {
  if (!meeting.startedAt || !meeting.endedAt) {
    return null;
  }
  const start = Date.parse(meeting.startedAt);
  const end = Date.parse(meeting.endedAt);
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) {
    return null;
  }
  const minutes = Math.round((end - start) / 60_000);
  return `${minutes} мин`;
}

function splitLines(text: string): string[] {
  return text
    .split(/\n+/)
    .map((line) => line.replace(/^[-•]\s*/, "").trim())
    .filter(Boolean);
}

function segmentAnchorId(id: string): string {
  return `segment-${id}`;
}

function itemAnchor(item: ActionItem, transcript: TranscriptSegment[]): string | null {
  if (item.segmentId) {
    return `#${segmentAnchorId(item.segmentId)}`;
  }
  if (item.timecodeMs == null) {
    return null;
  }
  const match = transcript.find((seg) => seg.startedAtMs === item.timecodeMs);
  return match ? `#${segmentAnchorId(match.id)}` : null;
}

const ASANA_STATE_LABEL: Record<ActionItem["asanaState"], string> = {
  none: "не отправлена",
  queued_for_asana: "к отправке",
  sent: "отправлена",
};

export function MeetingView({
  detail,
  asanaProjectLabel,
  asanaNotice,
  onAsanaQueue,
  onRetry,
  slides,
}: MeetingViewProps) {
  const { meeting, transcript, summary, actionItems } = detail;
  const slidesCapture =
    slides ?? unavailableSlides(demoMeeting.slides as SlideSlot[]);
  const isRealtime =
    meeting.status === "recording" || meeting.status === "transcribing";
  const caption = detail.realtime?.caption ?? realtimeCaption(meeting.source);
  const showRealtimeCaption =
    meeting.status !== "ready" &&
    (isRealtime || transcript.length > 0);
  const [query, setQuery] = useState("");
  const filteredTranscript = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) {
      return transcript;
    }
    return transcript.filter(
      (seg) =>
        seg.text.toLowerCase().includes(q) ||
        seg.speaker.toLowerCase().includes(q),
    );
  }, [transcript, query]);
  const queryId = "meeting-search";
  const pending = actionItems.filter((item) => item.asanaState === "none");
  const queued = actionItems.filter(
    (item) => item.asanaState === "queued_for_asana",
  );
  const sent = actionItems.filter((item) => item.asanaState === "sent");
  const asanaLabel =
    pending.length > 0
      ? `Отправить ${pending.length} ${taskWord(pending.length)} в Asana`
      : queued.length > 0
        ? "Задачи к отправке"
        : sent.length > 0
          ? "Задачи отправлены в Asana"
          : "Нет задач для отправки";
  const asanaDisabled = pending.length === 0;
  const datePart = meeting.startedAt ? formatDate(meeting.startedAt) : null;
  const duration = durationLabel(meeting);
  const subtitleParts = [meeting.title, datePart, duration].filter(Boolean);
  const decisions = summary ? splitLines(summary.decisions) : [];
  const risks = summary ? splitLines(summary.risks) : [];

  return (
    <section className="meeting">
      <header className="meeting__header">
        <div>
          <h1 className="meeting__title">Итоги встречи</h1>
          <p className="meeting__subtitle">{subtitleParts.join(" · ")}</p>
        </div>
        <div
          className={`meeting__badge meeting__badge--${meeting.status}`}
        >
          <span className="meeting__badge-dot" aria-hidden="true" />
          {STATUS_LABEL[meeting.status]}
        </div>
      </header>

      {meeting.status === "error" ? (
        <div className="meeting__alert" role="alert">
          <p>{meeting.error ?? "Конвейер остановился с ошибкой."}</p>
          <button type="button" className="meeting__retry" onClick={onRetry}>
            {meeting.audioPath ? "Повторить транскрибацию" : "Повторить"}
          </button>
        </div>
      ) : null}

      {isRealtime ? (
        <p className="meeting__progress">
          Сейчас: {STATUS_LABEL[meeting.status]}. Сегменты появляются по ходу.
        </p>
      ) : meeting.status !== "ready" && meeting.status !== "error" ? (
        <p className="meeting__progress">
          Сейчас: {STATUS_LABEL[meeting.status]}. Транскрипт и задачи появятся,
          когда обработка закончится.
        </p>
      ) : null}

      <section className="meeting__slides" aria-labelledby="slides-heading">
        <h2 id="slides-heading" className="meeting__col-title">
          Слайды
        </h2>
        <p className="meeting__slides-notice">{slidesCapture.notice}</p>
        {slidesCapture.slots.length > 0 ? (
          <ol className="meeting__slide-slots">
            {slidesCapture.slots.map((slot) => (
              <li key={slot.id} className="meeting__slide-slot">
                <span className="meeting__slide-title">{slot.title}</span>
                <time className="meeting__time">
                  {formatTimecode(slot.capturedAtMs)}
                </time>
              </li>
            ))}
          </ol>
        ) : null}
      </section>

      <div className="meeting__grid">
        <section className="meeting__col" aria-labelledby="transcript-heading">
          <h2 id="transcript-heading" className="meeting__col-title">
            Транскрипт встречи
          </h2>
          {showRealtimeCaption ? (
            <p className="meeting__realtime">{caption}</p>
          ) : null}
          <label className="meeting__search" htmlFor={queryId}>
            <span className="meeting__search-icon" aria-hidden="true">
              ⌕
            </span>
            <input
              id={queryId}
              type="search"
              placeholder="Поиск по словам и спикерам"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </label>
          <TranscriptList transcript={filteredTranscript} />
        </section>

        <section className="meeting__col" aria-labelledby="summary-heading">
          <h2 id="summary-heading" className="meeting__col-title">
            Краткое резюме
          </h2>
          <div className="meeting__result">
            <h3 className="meeting__block-title">Основной результат</h3>
            <p>{summary?.headline || "Резюме ещё не готово."}</p>
          </div>
          <div className="meeting__block">
            <h3 className="meeting__block-title">Решения</h3>
            {decisions.length > 0 ? (
              <ul>
                {decisions.map((line) => (
                  <li key={line}>{line}</li>
                ))}
              </ul>
            ) : (
              <p className="meeting__muted">Пока нет.</p>
            )}
          </div>
          <div className="meeting__block">
            <h3 className="meeting__block-title">Риски</h3>
            {risks.length > 0 ? (
              <ul>
                {risks.map((line) => (
                  <li key={line}>{line}</li>
                ))}
              </ul>
            ) : (
              <p className="meeting__muted">Пока нет.</p>
            )}
          </div>
          <div className="meeting__block">
            <h3 className="meeting__block-title">Следующий шаг</h3>
            <p>{summary?.nextStep || "Пока нет."}</p>
          </div>
          <div className="meeting__stats">
            <Stat value={transcript.length} label="фрагментов" />
            <Stat value={decisions.length} label="решения" />
            <Stat value={actionItems.length} label="задачи" />
          </div>
        </section>

        <section className="meeting__col" aria-labelledby="tasks-heading">
          <h2 id="tasks-heading" className="meeting__col-title">
            Задачи из встречи
          </h2>
          <p className="meeting__hint">
            Без токена Asana кнопка только помечает задачи к отправке.
          </p>
          <button
            type="button"
            className="meeting__asana"
            disabled={asanaDisabled}
            onClick={onAsanaQueue}
          >
            {asanaLabel}
          </button>
          {asanaNotice ? (
            <p className="meeting__asana-notice">{asanaNotice}</p>
          ) : null}
          <ul className="meeting__tasks">
            {actionItems.map((item) => {
              const href = itemAnchor(item, transcript);
              const when = item.dueAt ? formatDue(item.dueAt) : null;
              return (
                <li key={item.id} className="meeting__task">
                  <div className="meeting__task-top">
                    <span className="meeting__avatar" aria-hidden="true">
                      {(item.assignee ?? "?").slice(0, 1)}
                    </span>
                    <span className="meeting__assignee">
                      {item.assignee ?? "без ответственного"}
                    </span>
                    {item.timecodeMs != null ? (
                      href ? (
                        <a className="meeting__timecode" href={href}>
                          {formatTimecode(item.timecodeMs)}
                        </a>
                      ) : (
                        <span className="meeting__timecode">
                          {formatTimecode(item.timecodeMs)}
                        </span>
                      )
                    ) : null}
                  </div>
                  <p className="meeting__task-title">{item.title}</p>
                  <p className="meeting__asana-state">
                    Asana: {ASANA_STATE_LABEL[item.asanaState]}
                  </p>
                  {when ? (
                    <p className="meeting__due">Когда: {when}</p>
                  ) : null}
                </li>
              );
            })}
          </ul>
          <div className="meeting__asana-project">
            <strong>Проект Asana:</strong>{" "}
            {asanaProjectLabel || "не указан в этой версии"}
          </div>
        </section>
      </div>
    </section>
  );
}

function TranscriptList({ transcript }: { transcript: TranscriptSegment[] }) {
  if (transcript.length === 0) {
    return <p className="meeting__muted">Пока нет расшифровки.</p>;
  }
  return (
    <ol className="meeting__transcript">
      {transcript.map((seg) => (
        <li key={seg.id} id={segmentAnchorId(seg.id)}>
          <time className="meeting__time">
            {formatTimecode(seg.startedAtMs)}
          </time>
          <strong className="meeting__speaker">{seg.speaker}</strong>
          <p className="meeting__voiceprint">
            {seg.voiceprintLabel ?? VOICEPRINT_UNAVAILABLE}
          </p>
          <p className="meeting__line">{seg.text}</p>
        </li>
      ))}
    </ol>
  );
}

function Stat({ value, label }: { value: number; label: string }) {
  return (
    <div className="meeting__stat">
      <span className="meeting__stat-value">{value}</span>
      <span className="meeting__stat-label">{label}</span>
    </div>
  );
}

function taskWord(n: number): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) {
    return "задачу";
  }
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) {
    return "задачи";
  }
  return "задач";
}
