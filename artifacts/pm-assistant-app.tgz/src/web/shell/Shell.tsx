import { Outlet } from "react-router-dom";
import { Sidebar } from "./Sidebar.tsx";
import { TopBar } from "./TopBar.tsx";

export function Shell() {
  return (
    <div className="shell">
      <Sidebar />
      <div className="workspace">
        <TopBar />
        <main className="workspace__main">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
