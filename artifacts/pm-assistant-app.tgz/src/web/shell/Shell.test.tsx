import { renderToString } from "react-dom/server";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { describe, expect, it } from "vitest";
import { Shell } from "./Shell.tsx";

function renderShell(path: string) {
  return renderToString(
    <MemoryRouter initialEntries={[path]}>
      <Routes>
        <Route element={<Shell />}>
          <Route path="/" element={<p>главная-заглушка</p>} />
          <Route path="/calendar" element={<p>календарь-заглушка</p>} />
          <Route path="/archive" element={<p>архив-заглушка</p>} />
          <Route path="/integrations" element={<p>интеграции-заглушка</p>} />
          <Route path="/settings" element={<p>настройки-заглушка</p>} />
        </Route>
      </Routes>
    </MemoryRouter>,
  );
}

describe("Shell", () => {
  it("на Календаре помечает активный пункт и не показывает Команду и Биллинг", () => {
    const html = renderShell("/calendar");
    expect(html).toContain("Главная");
    expect(html).toContain("Календарь");
    expect(html).toContain("Расшифровки");
    expect(html).toContain("Интеграции");
    expect(html).toContain("Настройки");
    expect(html).not.toContain("Команда");
    expect(html).not.toContain("Биллинг");
    expect(html).toContain('aria-current="page"');
    expect(html).toMatch(/href="\/calendar"[^>]*aria-current="page"|aria-current="page"[^>]*href="\/calendar"/);
    expect(html).toContain("Поиск по встречам");
    expect(html).toContain("Календари не подключены");
  });
});
