import { BrowserRouter, Route, Routes } from "react-router-dom";
import { ArchivePlaceholder } from "./pages/archive/ArchivePlaceholder.tsx";
import { CalendarPlaceholder } from "./pages/calendar/CalendarPlaceholder.tsx";
import { Home } from "./pages/home/Home.tsx";
import { IntegrationsPlaceholder } from "./pages/integrations/IntegrationsPlaceholder.tsx";
import { MeetingPage } from "./pages/meeting/MeetingPage.tsx";
import { SettingsPlaceholder } from "./pages/settings/SettingsPlaceholder.tsx";
import { Shell } from "./shell/Shell.tsx";

export function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Shell />}>
          <Route path="/" element={<Home />} />
          <Route path="/calendar" element={<CalendarPlaceholder />} />
          <Route path="/archive" element={<ArchivePlaceholder />} />
          <Route path="/integrations" element={<IntegrationsPlaceholder />} />
          <Route path="/settings" element={<SettingsPlaceholder />} />
          <Route path="/meetings/:id" element={<MeetingPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
